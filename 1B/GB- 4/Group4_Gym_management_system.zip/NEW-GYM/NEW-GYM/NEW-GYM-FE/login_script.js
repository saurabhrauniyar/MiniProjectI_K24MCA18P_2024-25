// OLD CODE
// document.addEventListener('DOMContentLoaded', function() {
//     const loginButton = document.querySelector('.clkbtn');

//     loginButton.addEventListener('click', function() {
//         // Get input values
//         const email = document.querySelector('.email').value.trim();
//         const password = document.querySelector('.password').value;

//         // Basic validation
//         if (!email || !password) {
//             alert('Please fill in all fields');
//             return;
//         }

//         // Email format validation
//         const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
//         if (!emailPattern.test(email)) {
//             alert('Please enter a valid email address');
//             return;
//         }

//         // Get users from localStorage
//         const users = JSON.parse(localStorage.getItem('users')) || [];

//         // Find user with matching email
//         const user = users.find(user => user.email === email);

//         // Check if user exists and password matches
//         if (user && user.password === password) {
//             // Store login status
//             localStorage.setItem('currentUser', JSON.stringify({
//                 name: user.name,
//                 email: user.email,
//                 isLoggedIn: true
//             }));

//             // Show success message
//             alert('Login successful!');

//             // Redirect to index page
//             window.location.href = 'index.html';
//         } else {
//             alert('Invalid email or password');
//         }
//     });

//     // Check if user is already logged in
//     const currentUser = JSON.parse(localStorage.getItem('currentUser'));
//     if (currentUser && currentUser.isLoggedIn) {
//         window.location.href = 'index.html';
//     }
// });

// NEW CODE

document.addEventListener("DOMContentLoaded", function () {
  const loginForm = document.getElementById("login-form");
  const loader = document.getElementById("loader");

  loginForm.addEventListener("submit", function (e) {
    e.preventDefault(); // Prevent form submission

    // Get input values

    loader.style.display = "block";
    const email = document.querySelector('input[name="email"]').value.trim();
    const password = document.querySelector('input[name="password"]').value;

    // Basic validation
    if (!email || !password) {
      alert("Please fill in all fields");
      return;
    }

    // Email format validation
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
      alert("Please enter a valid email address");
      return;
    }

    // Fetch login API
    fetch("https://new-gym-be.vercel.app/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email: email, password: password }),
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.message) {
          loader.style.display = "none";
          // Store login status in localStorage
          localStorage.setItem("isLoggedIn", true);
          // Show success message
          alert("Login successful!");

          // Redirect to index page
          window.location.href = "index.html";
        } else if (data.error) {
          loader.style.display = "none";
          alert(data.error);
        }
      })
      .catch((error) => {
        loader.style.display = "none";
        console.error("Error:", error);
        alert("An error occurred while logging in. Please try again later.");
      });
  });

  // Check if user is already logged in
  const currentUser = JSON.parse(localStorage.getItem("currentUser"));
  if (currentUser && currentUser.isLoggedIn) {
    alert("You are already logged in!");
    window.location.href = "index.html";
  }
});
