This is a side-project where I have created a movie reservation UI using backbone.
It took me about 8-10 hours to complete this. It is just for learning right now .
