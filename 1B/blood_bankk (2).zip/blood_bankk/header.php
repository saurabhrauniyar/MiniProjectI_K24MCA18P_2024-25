<header>
    <h1>Blood Donation Initiative</h1>
    <nav>
        <ul>
            <li><a href="/index.php">Home</a></li>
            <li><a href="/donor-register.php">Register as Donor</a></li>
        </ul>
    </nav>
</header>