module.exports= {
    mongoUrl:'mongodb+srv://daudansarikld:KwMDtO41qW4CIDx5@cluster0.588md.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0',
    // mongoUrl:'mongodb+srv://Shubh123456:1bsdhahbashjdhjasvdjbvasgdc@cluster0.tgotj.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0',
    secret:"fiudshfi"

}