import React from 'react'

function Status() {
  return (
    <div>Status</div>
  )
}

export default Status