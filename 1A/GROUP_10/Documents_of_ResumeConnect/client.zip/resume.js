

document.getElementById('downloadPdf').addEventListener('click', () => {
  const resumeElement = document.querySelector('.container');
  const downloadButton = document.getElementById('downloadPdf');
  const databaseButton = document.getElementById('database');

  // Temporarily hide the "Download PDF" button
  downloadButton.style.display = 'none';
  databaseButton.style.display = 'none';

  const options = {
    margin: 10, // Set margin around the content
    filename: 'resume.pdf',
    image: { type: 'jpeg', quality: 0.98 },
    html2canvas: { scale: 2 }, // Increase canvas scaling for better quality
    jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }, // A4 size
    pagebreak: { mode: ['avoid-all', 'css', 'legacy'] }, // Avoid breaking elements
  };

  // Generate and download the PDF
  html2pdf().set(options).from(resumeElement).save().then(() => {
    // Make the button visible again after generating the PDF
    downloadButton.style.display = 'block';
    databaseButton.style.display = 'block';
  });
});



// Add the following JavaScript to handle dropdown visibility:

document.querySelectorAll('.emp-btn').forEach(button => {
  button.addEventListener('click', () => {
    const dropdown = button.nextElementSibling;

    // Toggle visibility of the dropdown
    if (dropdown.style.display === 'none' || dropdown.style.display === '') {
      dropdown.style.display = 'block';
    } else {
      dropdown.style.display = 'none';
    }
  });
});


//  js for link part

const addLinkButton = document.querySelector('.link-btn');
const dropdownContent = document.querySelector('.link-content');
const linksList = document.querySelector('.links-list');

// Toggle dropdown visibility
addLinkButton.addEventListener('click', () => {
  dropdownContent.style.display = dropdownContent.style.display === 'block' ? 'none' : 'block';
});

// Handle adding links
const addLinkBtn = document.querySelector('.add-link-btn');
addLinkBtn.addEventListener('click', () => {
  const platform = document.querySelector('#platform').value;
  const urlInput = dropdownContent.querySelector('input[type="text"]');
  const url = urlInput.value;

  if (url) {
    // Create a new link element
    const linkItem = document.createElement('div');
    linkItem.className = 'link-item';
    linkItem.innerHTML = `
      <strong>${platform}:</strong> <a href="${url}" target="_blank">${url}</a>
      <button type="button" class="remove-link-btn">Remove</button>
    `;

    // Append to the list
    linksList.appendChild(linkItem);

    // Clear the input field
    urlInput.value = '';
  } else {
    alert('Please enter a valid URL.');
  }
});

// Handle removing links
linksList.addEventListener('click', (event) => {
  if (event.target.classList.contains('remove-link-btn')) {
    event.target.parentElement.remove();
  }
});

// JavaScript for "Add Section"

const dynamicSections = document.getElementById('dynamic-sections');
const addSectionButtons = document.querySelectorAll('.add-section-btn');

// Event listener for "Add Section" buttons
addSectionButtons.forEach((button) => {
  button.addEventListener('click', () => {
    const sectionType = button.textContent.replace('+ ', '').trim(); // Get the section type
    addDynamicSection(sectionType);
  });
});

// Function to add a new dynamic section
function addDynamicSection(sectionType) {
  // Create a container for the new section
  const sectionContainer = document.createElement('div');
  sectionContainer.className = 'dynamic-section';

  // Add section header and remove button
  sectionContainer.innerHTML = `
    <h3>${sectionType}</h3>
    <textarea placeholder="Enter details for ${sectionType}..."></textarea>
    <button type="button" class="remove-section-btn">Remove Section</button>
  `;

  // Append the new section to the dynamic sections container
  dynamicSections.appendChild(sectionContainer);

  // Add an event listener to the remove button
  const removeButton = sectionContainer.querySelector('.remove-section-btn');
  removeButton.addEventListener('click', () => {
    sectionContainer.remove();
  });
}

