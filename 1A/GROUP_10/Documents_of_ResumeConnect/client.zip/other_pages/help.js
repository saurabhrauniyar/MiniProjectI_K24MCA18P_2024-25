// Toggle chat window visibility
function toggleChat() {
    const chatWindow = document.getElementById("chatWindow");
    chatWindow.style.display = chatWindow.style.display === "flex" ? "none" : "flex";
}

// Handle predefined options
function handleOption(option) {
    const chatBody = document.querySelector(".chat-body");
    const newMessage = document.createElement("p");
    newMessage.textContent =" You selected: ${option}";
    chatBody.appendChild(newMessage);
}

// Handle user input
function sendMessage() {
    const userInput = document.getElementById("userInput");
    if (userInput.value.trim() !== "") {
        const chatBody = document.querySelector(".chat-body");
        const userMessage = document.createElement("p");
        userMessage.textContent = ` Response for : ${userInput.value}`;
        chatBody.appendChild(userMessage);
        userInput.value = ""; // Clear input field
    }
}