// document.getElementById('generate-pdf').addEventListener('click', () => {
//     // Get input values
//     const name = document.getElementById('name').value;
//     const jobTitle = document.getElementById('job-title').value;
//     const contact = document.getElementById('contact').value;
//     const address = document.getElementById('address').value;
//     const skills = document.getElementById('skills').value.split(',');
//     const summary = document.getElementById('summary').value;
//     const employment = document.getElementById('employment').value;
//     const education = document.getElementById('education').value;
  
//     // Populate preview
//     document.getElementById('preview-name').textContent = name;
//     document.getElementById('preview-job-title').textContent = jobTitle;
//     document.getElementById('preview-contact').textContent = contact;
//     document.getElementById('preview-address').textContent = address;
//     document.getElementById('preview-summary').textContent = summary;
//     document.getElementById('preview-employment').textContent = employment;
//     document.getElementById('preview-education').textContent = education;
  
//     const skillsList = document.getElementById('preview-skills');
//     skillsList.innerHTML = '';
//     skills.forEach(skill => {
//       const li = document.createElement('li');
//       li.textContent = skill.trim();
//       skillsList.appendChild(li);
//     });
  
//     // Show preview
//     document.getElementById('resume-preview').style.display = 'block';
  
//     // Generate PDF
//     const resume = document.getElementById('resume');
//     const pdfOptions = {
//       margin: [10, 10],
//       filename: `${name}_Resume.pdf`,
//       html2canvas: { scale: 2 },
//       jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
//     };
  
//     html2pdf().set(pdfOptions).from(resume).save();
//   });
  




document.getElementById("generate-pdf").addEventListener("click", () => {
    const formData = {
      name: document.getElementById("name").value,
      title: document.getElementById("title").value,
      contact: document.getElementById("contact").value,
      email: document.getElementById("email").value,
      address: document.getElementById("address").value,
      skills: document.getElementById("skills").value.split(","),
      projects: document.getElementById("projects").value.split(","),
      education: document.getElementById("education").value.split(","),
      certifications: document.getElementById("certifications").value.split(","),
      languages: document.getElementById("languages").value.split(","),
      hobbies: document.getElementById("hobbies").value.split(","),
      employment: Array.from(document.querySelectorAll(".employment")).map((job, index) => ({
        company: document.getElementById(`company${index + 1}`).value,
        role: document.getElementById(`role${index + 1}`).value,
        duration: document.getElementById(`duration${index + 1}`).value,
        description: document.getElementById(`description${index + 1}`).value,
      })),
    };
  
    const resumeContent = `
      <div id="resume-template">
        <h1>${formData.name}</h1>
        <h3>${formData.title}</h3>
        <p>${formData.contact} | ${formData.email} | ${formData.address}</p>
  
        <h2>Skills</h2>
        <ul>${formData.skills.map(skill => `<li>${skill.trim()}</li>`).join("")}</ul>
  
        <h2>Employment History</h2>
        ${formData.employment
          .map(
            job => `
          <h3>${job.company}</h3>
          <p><strong>${job.role}</strong> (${job.duration})</p>
          <p>${job.description}</p>
        `
          )
          .join("")}
  
        <h2>Projects</h2>
        <ul>${formData.projects.map(project => `<li>${project.trim()}</li>`).join("")}</ul>
  
        <h2>Education</h2>
        <ul>${formData.education.map(edu => `<li>${edu.trim()}</li>`).join("")}</ul>
  
        <h2>Certifications</h2>
        <ul>${formData.certifications.map(cert => `<li>${cert.trim()}</li>`).join("")}</ul>
  
        <h2>Languages</h2>
        <ul>${formData.languages.map(lang => `<li>${lang.trim()}</li>`).join("")}</ul>
  
        <h2>Hobbies</h2>
        <ul>${formData.hobbies.map(hobby => `<li>${hobby.trim()}</li>`).join("")}</ul>
      </div>
    `;
  
    const preview = document.getElementById("resume-preview");
    preview.innerHTML = resumeContent;
    preview.style.display = "block";
  
    const options = {
      margin: 0.5,
      filename: `${formData.name.replace(" ", "_")}_Resume.pdf`,
      image: { type: "jpeg", quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: "in", format: "letter", orientation: "portrait" },
    };
  
    html2pdf().from(preview).set(options).save();
  });



  
  