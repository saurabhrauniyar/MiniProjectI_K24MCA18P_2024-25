// Handle user registration
document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("userForm");
    const userList = document.getElementById("users");

    form.addEventListener("submit", function (e) {
        e.preventDefault();

        const username = document.getElementById("username").value;
        const email = document.getElementById("email").value;

        if (username && email) {
            // Add the user to the list
            const listItem = document.createElement("li");
            listItem.textContent = `Name: ${username}, Email: ${email}`;
            userList.appendChild(listItem);

            // Clear form inputs
            form.reset();
        }
    });
});
