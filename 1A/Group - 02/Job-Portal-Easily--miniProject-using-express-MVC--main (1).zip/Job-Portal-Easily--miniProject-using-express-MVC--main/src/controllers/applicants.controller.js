import path from 'path';
import ApplicantsModel from '../models/applicants.model.js';
import JobModel from  '../models/jobs.model.js'
import { uploadFile } from '../middlewares/file-upload.middleware.js';

export default class ApplicantsController{  

    getApplicants(req, res){
        let applicant = ApplicantsModel.get();
        res.render("applicants",{applicant, userEmail : req.session.userEmail});
    }

    addNewApplicants(req, res, next){
        const {applicantname,emailid,applicantcontact} = req.body;
        const resume = 'resume/' + req.file.filename;



        const validationErrors = ApplicantsModel.validate(
            applicantname,
            emailid,
            applicantcontact,
            resume
        );
    
        if (validationErrors.length > 0) {
            // If errors exist, send them back as a response
            return res.status(400).json({
                success: false,
                errors: validationErrors,
            });
        }
    


        ApplicantsModel.add(applicantname,emailid,applicantcontact,resume);

        res.status(201).json({
            success: true,
            message: "Applicant added successfully!",
        });
        // var applicant = ApplicantsModel.get();
        // var job = JobModel.get();
        // return res.render('jobs',{applicant,job, userEmail : req.session.userEmail});  
      
    }

}