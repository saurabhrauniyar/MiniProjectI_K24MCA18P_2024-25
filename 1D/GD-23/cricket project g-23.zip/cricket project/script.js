// let Impir = document.querySelector("#Ename")
// let dat = document.querySelector("#match_date")
// let linkk = document.querySelector("#submit")


// if(Impir.value==''){
//   alert("please fill up the all required information")
// }
// else{
//   linkk.style.displ=
// }

// linkk.addEventListener('click',()=>{
//   if()
// })

