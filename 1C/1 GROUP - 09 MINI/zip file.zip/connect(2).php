<?php
// Database credentials
$dbhost = "sql102.infinityfree.com"; // MySQL Hostname
$dbuser = "if0_37784680";           // MySQL Username
$dbpass = "Saurabh98878767";        // MySQL Password
$dbname = "if0_37784680_login";     // MySQL Database Name

// Create connection
$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Failed to connect to MySQL: " . $conn->connect_error);
}
echo "";
?>
