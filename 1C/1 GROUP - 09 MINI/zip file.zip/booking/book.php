<?php
// Database configuration
$host = 'sql102.infinityfree.com';  // Change to your database host
$dbname = 'if0_37784680_booking'; // Change to your database name
$username = 'if0_37784680';  // Change to your database username
$password = 'Saurabh98878767';  // Change to your database password

// Create a PDO instance
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get and sanitize form data
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $phone = htmlspecialchars($_POST['phone']);
    $address = htmlspecialchars($_POST['address']);
    $date = htmlspecialchars($_POST['date']);
    $time = htmlspecialchars($_POST['time']);
    $package = htmlspecialchars($_POST['package']);
    
    // Insert the data into the database
    try {
        $stmt = $pdo->prepare("INSERT INTO bookings (name, email, phone, address, date, time, package) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$name, $email, $phone, $address, $date, $time, $package]);

        // Show confirmation message
        echo "<script>document.getElementById('confirmationMessage').innerHTML = 'Booking confirmed! We will contact you soon.';</script>";
    } catch (PDOException $e) {
        echo "<script>document.getElementById('confirmationMessage').innerHTML = 'Error: " . $e->getMessage() . "';</script>";
    }
}
?>
