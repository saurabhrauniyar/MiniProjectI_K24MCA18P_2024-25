<?php
session_start();

// Check if user is logged in by verifying session variable
if (isset($_SESSION['username'])) {
    // Display user information
    echo "" . $_SESSION[''] . " " . $_SESSION['password'] . "";
} else {
    // If not logged in, redirect to the login page
    header("Location: login1.php");
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Cleaning Packages</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, 
            Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
            background-color: #0f0f0ea8;
            color: #333;
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
        }

        header {
            background-color: #072dab;
            color: white;
            padding: 40px 0;
            text-align: center;
        }

        header h1 {
            font-size: 2.5rem;
        }

        header p {
            font-size: 1.2rem;
            margin-top: 10px;
        }

        .packages {
            display: flex;
            justify-content: space-between;
            gap: 20px;
            flex-wrap: wrap;
            margin-top: 40px;
        }

        .package-card {
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            padding: 30px;
            width: 30%;
            text-align: center;
            transition: transform 0.3s ease;
            margin-bottom: 30px;
        }

        .package-card:hover {
            transform: translateY(-10px);
        }

        .package-card h2 {
            font-size: 1.8rem;
            margin-bottom: 20px;
            color: #4CAF50;
        }

        .package-card .price {
            font-size: 1.5rem;
            color: #2238ffbd;
            margin-bottom: 20px;
        }

        .package-card ul {
            list-style-type: none;
            margin-bottom: 20px;
        }

        .package-card ul li {
            font-size: 1.1rem;
            margin-bottom: 10px;
        }

        .package-card button {
            padding: 10px 20px;
            background-color: #11130cb3;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1.1rem;
            transition: background-color 0.3s ease;
        }

        .package-card button:hover {
            background-color: #1f0adc;
        }

        table {
            width: 100%;
            margin-top: 50px;
            border-collapse: collapse;
            margin-bottom: 50px;
        }

        th,
        td {
            padding: 12px;
            text-align: center;
            border: 1px solid #ddd;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }

        td {
            background-color: #f9f9f9;
        }

        footer {
            background-color: #333;
            color: white;
            padding: 20px 0;
            text-align: center;
        }

        footer p {
            font-size: 1rem;
        }

        /* Media Queries */
        @media (max-width: 1200px) {
            .packages {
                justify-content: space-around;
            }

            .package-card {
                width: 45%;
            }
        }

        @media (max-width: 768px) {
            .packages {
                flex-direction: column;
                align-items: center;
            }

            .package-card {
                width: 80%;
            }

            table {
                font-size: 14px;
            }

            header h1 {
                font-size: 2rem;
            }

            header p {
                font-size: 1rem;
            }

            footer p {
                font-size: 0.9rem;
            }
        }

        @media (max-width: 480px) {
            .package-card {
                width: 90%;
                padding: 20px;
            }

            header h1 {
                font-size: 1.5rem;
            }

            header p {
                font-size: 0.9rem;
            }

            footer p {
                font-size: 0.8rem;
            }
        }
    </style>
</head>

<body>
    <header>
        <div class="container">
            <h1>Home Cleaning Packages</h1>
            <p>Choose the right cleaning package for your home</p>
        </div>
    </header>

    <!-- Packages Section -->
    <section class="packages">
        <div class="package-card">
            <h2>Basic Plan</h2>
            <b>
                <p class="price">1500 RS/-</p>
            </b>
            <ul>
                <li>Dusting of all surfaces</li>
                <li>Sweeping and mopping floors</li>
                <li>Vacuuming carpeted areas</li>
                <li>Kitchen countertops and exterior appliances cleaning</li>
                <li>Bathroom cleaning (sinks, mirrors, toilets)</li>
                <li>Trash removal</li>
                <li>Basic tidying up</li>
            </ul>
            <a href="booking/booking.php"><button>Book Now</button></a>
        </div>

        <div class="package-card">
            <h2>Silver Plan</h2>
            <b>
                <p class="price">2500 RS/-</p>
            </b>
            <ul>
                <li>Everything in Basic Cleaning</li>
                <li>Detailed dusting (blinds, light fixtures, baseboards)</li>
                <li>Deep kitchen cleaning (appliance interiors)</li>
                <li>Deep bathroom clean (showers, bathtubs, sinks)</li>
                <li>Extra attention to high-traffic areas</li>
                <li>Furniture cleaning</li>
                <li>Optional bed linen change</li>
            </ul>
            <a href="booking/booking.php"><button>Book Now</button></a>
        </div>

        <div class="package-card">
            <h2>Gold Plan</h2>
            <b>
                <p class="price">5000 RS/-</p>
            </b>
            <ul>
                <li>Everything in Best Cleaning</li>
                <li>High touch point disinfection</li>
                <li>Deep carpet and rug cleaning</li>
                <li>Window cleaning (interior)</li>
                <li>Deep oven and refrigerator cleaning</li>
                <li>Cabinet and drawer cleaning</li>
                <li>Air vent & baseboard cleaning</li>
                <li>Optional extra services (pressure washing, carpet deodorizing)</li>
            </ul>
            <a href="booking/booking.php"><button>Book Now</button></a>
        </div>
    </section>

    <!-- Comparison Table -->
    <section class="table-comparison">
        <table>
            <thead>
                <tr>
                    <th>Feature</th>
                    <th>Basic Plan</th>
                    <th>Silver Plan</th>
                    <th>Gold Plan</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Dusting & Sweeping</td>
                    <td>✔️</td>
                    <td>✔️</td>
                    <td>✔️</td>
                </tr>
                <tr>
                    <td>Vacuuming</td>
                    <td>✔️</td>
                    <td>✔️</td>
                    <td>✔️</td>
                </tr>
                <tr>
                    <td>Kitchen Cleaning (Exterior)</td>
                    <td>✔️</td>
                    <td>✔️</td>
                    <td>✔️</td>
                </tr>
                <tr>
                    <td>Deep Bathroom Cleaning</td>
                    <td>✔️</td>
                    <td>✔️</td>
                    <td>✔️</td>
                </tr>
                <tr>
                    <td>Detailed Dusting</td>
                    <td>❌</td>
                    <td>✔️</td>
                    <td>✔️</td>
                </tr>
                <tr>
                    <td>High Touch Point Disinfection</td>
                    <td>❌</td>
                    <td>❌</td>
                    <td>✔️</td>
                </tr>
                <tr>
                    <td>Deep Carpet & Rug Cleaning</td>
                    <td>❌</td>
                    <td>❌</td>
                    <td>✔️</td>
                </tr>
                <tr>
                    <td>Oven & Refrigerator Deep Clean</td>
                    <td>❌</td>
                    <td>❌</td>
                    <td>✔️</td>
                </tr>
                <tr>
                    <td>Window Cleaning</td>
                    <td>❌</td>
                    <td>❌</td>
                    <td>✔️</td>
                </tr>
                <tr>
                    <td>Optional Extra Services</td>
                    <td>❌</td>
                    <td>❌</td>
                    <td>✔️</td>
                </tr>
            </tbody>
        </table>
    </section>

    <footer>
        <div class="container">
            <p>&copy; Cleaning Zone 2024 | All Rights Reserved</p>
        </div>
    </footer>
</body>

</html>
