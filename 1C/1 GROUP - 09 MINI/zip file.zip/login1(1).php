



<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Home</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width" />
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/css/bootstrap.min.css'>
    <link rel='stylesheet' href='inline.css'>
    <link rel='stylesheet' href='https://unicons.iconscout.com/release/v2.1.9/css/unicons.css'>
  </head>
  <body>
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-12 text-center py-5">
          <h6 class="mb-0 pb-3">
            <span id="login-tab" style="cursor: pointer;">Log In</span> | 
            <span id="signup-tab" style="cursor: pointer;">Sign Up</span>
          </h6>
          <div class="card">
            <div class="card-body">
              <!-- Login Form -->
              <div id="login-form">
                <h4 class="mb-4">Log In</h4>
                <form action="" method="POST">
                  <div class="form-group">
                    <input type="text" name="username" class="form-control" placeholder="Your Username" required />
                  </div><br>
                  <div class="form-group">
                    <input type="password" name="password" class="form-control" placeholder="Your Password" required />
                  </div><br>
                  <input type="submit" name="login" class="btn btn-primary" value="Log In" />
                </form>
                <p class="mt-2"><a href="#" class="link" id="forgot-password-link">Forgot your password?</a></p>
              </div>

              <!-- Forgot Password Form -->
              <div id="forgot-password-form" style="display: none;">
                <h4 class="mb-4">Reset Password</h4>
                <form action="" method="POST">
                  <div class="form-group">
                    <input type="email" name="email" class="form-control" placeholder="Your Email" required />
                  </div><br>
                  <input type="submit" name="send-otp" class="btn btn-primary" value="Reset Password" />
                </form>
                <p class="mt-2"><a href="#" class="link" id="back-to-login">Back to Login</a></p>
              </div>

              <!-- OTP Verification Form -->
              <div id="otp-form" style="display: none;">
                <h4 class="mb-4">Enter OTP</h4>
                <form action="" method="POST">
                  <div class="form-group">
                    <input type="text" name="otp" class="form-control" placeholder="Enter OTP" required />
                  </div>
                  <div class="form-group">
                    <input type="password" name="new-password" class="form-control" placeholder="New Password" required />
                  </div>
                  <input type="submit" name="verify-otp" class="btn btn-primary" value="Verify OTP and Reset Password" />
                </form>
              </div>

              <!-- Sign Up Form -->
              <div id="signup-form" style="display: none;">
                <h4 class="mb-4">Sign Up</h4>
                <form action="" method="POST">
                  <div class="form-group">
                    <input type="text" name="username" class="form-control" placeholder="Your Username" required />
                  </div><br>
                  <div class="form-group">
                    <input type="email" name="email" class="form-control" placeholder="Your Email" required />
                  </div><br>
                  <div class="form-group">
                    <input type="password" name="password" class="form-control" placeholder="Your Password" required />
                  </div><br>
                  <input type="submit" name="signup" class="btn btn-primary" value="Sign Up" />
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <?php
      // Database credentials
      $dbhost = "sql102.infinityfree.com";
      $dbuser = "if0_37784680";
      $dbpass = "Saurabh98878767";
      $dbname = "if0_37784680_login";

      // Create connection
      $conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

      // Check connection
      if ($conn->connect_error) {
          die("Failed to connect to MySQL: " . $conn->connect_error);
      }

      session_start();
      $otp = "";
      $emailToSendOTP = "";
      $otpStoredInSession = "";

      // Handle Login
      if (isset($_POST['login'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];
        $query = "SELECT * FROM `users` WHERE `username`='$username' AND `password`='$password'";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) == 1) {
          $_SESSION['username'] = $username; // Store username in session
          echo "<h3>Login successful! Welcome, $username.</h3>";
          
          // Redirect to dashboard page
          header("Location: indexlogin.php");
          exit(); // Terminate script execution after redirect
        } else {
          echo "<p class='error'>Invalid username or password. Please try again.</p>";
        }
      }

      // Handle Forgot Password (Send OTP)
      if (isset($_POST['send-otp'])) {
        $email = $_POST['email'];

        // Check if the email exists in the database
        $query = "SELECT * FROM `users` WHERE `email`='$email'";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) == 1) {
          // Generate OTP
          $otp = rand(100000, 999999); // 6-digit OTP
          $_SESSION['otp'] = $otp;  // Store OTP in session
          $_SESSION['email'] = $email;  // Store email in session

          // Send OTP to the email (Using PHP's mail function)
          mail($email, "Password Reset OTP", "Your OTP for password reset is: $otp");

          echo "<h3>An OTP has been sent to your email.</h3>";
          echo "<p>Check your inbox for the OTP.</p>";

          // Show OTP form
          echo '<script>document.getElementById("otp-form").style.display = "block";</script>';
          echo '<script>document.getElementById("forgot-password-form").style.display = "none";</script>';
        } else {
          echo "<p class='error'>No account found with that email address.</p>";
        }
      }

      // Handle OTP Verification and Password Reset
      if (isset($_POST['verify-otp'])) {
        $enteredOtp = $_POST['otp'];
        $newPassword = $_POST['new-password'];

        // Check if the entered OTP matches the one stored in the session
        if ($enteredOtp == $_SESSION['otp']) {
          // Update the user's password in the database
          $email = $_SESSION['email'];
          $query = "UPDATE `users` SET `password`='$newPassword' WHERE `email`='$email'";
          if (mysqli_query($conn, $query)) {
            echo "<h3>Password reset successful! You can now log in with your new password.</h3>";
            echo "<p><a href='#'>Go to Login</a></p>";
            unset($_SESSION['otp']); // Clear OTP session
            unset($_SESSION['email']); // Clear email session
          } else {
            echo "<p class='error'>Failed to update the password. Please try again later.</p>";
          }
        } else {
          echo "<p class='error'>Invalid OTP. Please try again.</p>";
        }
      }

      // Handle Sign Up
      if (isset($_POST['signup'])) {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = $_POST['password'];

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
          echo 'The Email you have entered is invalid, please try again.';
        } else {
          $query = "INSERT INTO `users` (`username`, `password`, `email`) VALUES ('$username', '$password', '$email')";
          $result1 = mysqli_query($conn, $query);

          if ($result1) {
            echo "<div class='form'>
                    <h3>You are registered successfully.</h3>
                    <br/>Click here to start <a href='#'>Login</a></div>";
          }
        }
      }

      $conn->close();
    ?>

    <script>
      // Toggle between login, signup, and forgot password forms
      document.getElementById("login-tab").addEventListener("click", function() {
        document.getElementById("login-form").style.display = "block";
        document.getElementById("signup-form").style.display = "none";
        document.getElementById("forgot-password-form").style.display = "none";
      });

      document.getElementById("signup-tab").addEventListener("click", function() {
        document.getElementById("signup-form").style.display = "block";
        document.getElementById("login-form").style.display = "none";
        document.getElementById("forgot-password-form").style.display = "none";
      });

      document.getElementById("forgot-password-link").addEventListener("click", function() {
        document.getElementById("forgot-password-form").style.display = "block";
        document.getElementById("login-form").style.display = "none";
        document.getElementById("signup-form").style.display = "none";
      });

      document.getElementById("back-to-login").addEventListener("click", function() {
        document.getElementById("forgot-password-form").style.display = "none";
        document.getElementById("login-form").style.display = "block";
        document.getElementById("signup-form").style.display = "none";
      });
    </script>
  </body>
</html>
