

<?php

session_start();

// Check if user is logged in by verifying session variable
if (isset($_SESSION['username'])) {
    // Display user information
    echo "Welcome, " . $_SESSION['username'] . " " . $_SESSION['password'] . "";
} else {
    // If not logged in, redirect to the login page
    header("Location: login1.php");
    exit();
}



// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Database connection setup
$servername = "localhost";
$username = "root";  // Update with your database username
$password = "";  // Update with your database password
$dbname = "home_cleaning";  // Database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
$confirmationMessage = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    $package = $_POST['package'];

    // Validate that the required fields are filled
    if (empty($name) || empty($email) || empty($phone) || empty($address) || empty($date) || empty($time)) {
        $confirmationMessage = "All fields are required!";
    } else {
        // Prepare SQL query with placeholders
        $stmt = $conn->prepare("INSERT INTO home_cleaning_bookings (name, email, phone, address, date, time, package) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssss", $name, $email, $phone, $address, $date, $time, $package);

        // Execute the query and check if successful
        if ($stmt->execute()) {
            $confirmationMessage = "Booking successfully made!";
        } else {
            $confirmationMessage = "Error: " . $stmt->error;
        }

        // Close the prepared statement
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Cleaning Booking</title>
    <style>
        * {
            box-sizing: border-box;
        }
        body {
            background-image: url('./team-4.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            font-family: Arial, sans-serif;
        }

        #p1 {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .container {
            background-color: rgb(49, 28, 28);
            padding: 20px;
            width: 450px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(223, 34, 34, 0.2);
        }

        h2 {
            text-align: center;
            color: #207fb6;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-top: 10px;
            color: #f5eaea;
        }

        input, select, button {
            padding: 8px;
            margin-top: 5px;
            border-radius: 4px;
            border: 1px solid #e6dbdb;
        }

        button {
            background-color: #6a16d8;
            color: white;
            border: none;
            cursor: pointer;
            margin-top: 15px;
        }

        button:hover {
            background-color: #5f1622;
        }

        #confirmationMessage {
            text-align: center;
            margin-top: 15px;
            color: #4CAF50;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div id="p1">
        <div class="container">
            <h2>Home Cleaning Booking</h2>
            <form id="bookingForm" method="POST" action="">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required>

                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>

                <label for="phone">Phone:</label>
                <input type="tel" id="phone" name="phone" required>

                <label for="address">Home Address:</label>
                <input type="text" id="address" name="address" required>

                <label for="date">Date:</label>
                <input type="date" id="date" name="date" required>

                <label for="time">Time:</label>
                <input type="time" id="time" name="time" required>

                <label for="package">Cleaning Package:</label>
                <select id="package" name="package" required>
                    <option value="basic">Basic Cleaning</option>
                    <option value="deep">Deep Cleaning</option>
                    <option value="move-out">Move-out Cleaning</option>
                </select>

                <button type="submit">Book Now</button>
            </form>

            <div id="confirmationMessage">
                <?php if (isset($confirmationMessage)) { echo $confirmationMessage; } ?>
            </div>
        </div>
    </div>

    <script>
        // Simple client-side validation (optional)
        document.getElementById('bookingForm').addEventListener('submit', function (event) {
            let form = event.target;
            let name = form.name.value;
            if (name.trim() === "") {
                alert("Please enter your name.");
                event.preventDefault();
            }
        });
    </script>
</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
