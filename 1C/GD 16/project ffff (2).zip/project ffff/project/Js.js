function chat() {
    const input = document.getElementById("text");
    const maindiv = document.getElementById("uldiv");
    var value = input.value;
    const liItem = document.createElement('li');
    liItem.className = "chat outgoing";
    liItem.innerHTML = `<p>${value}</p>`;
    maindiv.append(liItem);
    input.value = '';
    if(value=='Hii'){
        var str = 'Hello';
        
        const liItem1 = document.createElement('li');
    liItem1.className = "chat incoming";
    liItem1.innerHTML = `<span class="material-symbols-outlined">smart_toy</span>
                    <p>${str}</p>`;
    maindiv.append(liItem1);
    }
    else if(value=='Hello'){
        var str = 'hello';
        
        const liItem1 = document.createElement('li');
    liItem1.className = "chat incoming";
    liItem1.innerHTML = `<span class="material-symbols-outlined">smart_toy</span>
                    <p>${str}</p>`;
    maindiv.append(liItem1);
    }
    else if(value=='Who are you?'){
        var str = 'I am a chatbot how can I help you?';
        
        const liItem1 = document.createElement('li');
    liItem1.className = "chat incoming";
    liItem1.innerHTML = `<span class="material-symbols-outlined">smart_toy</span>
                    <p>${str}</p>`;
    maindiv.append(liItem1);
    }
    else if(value=='I need help?'){
        var str = 'Yes tell me your problem then, I can help you ?';
        
        const liItem1 = document.createElement('li');
    liItem1.className = "chat incoming";
    liItem1.innerHTML = `<span class="material-symbols-outlined">smart_toy</span>
                    <p>${str}</p>`;
    maindiv.append(liItem1);
    }
    else if(value=='Does the college offer online degree programs?'){
        var str = 'No, we  dont offer online degree.';
        
        const liItem1 = document.createElement('li');
    liItem1.className = "chat incoming";
    liItem1.innerHTML = `<span class="material-symbols-outlined">smart_toy</span>
                    <p>${str}</p>`;
    maindiv.append(liItem1);
    }
    else if(value=='What clubs and organizations are available?'){
        var str = 'We have over 100 student organizations, including academic, cultural, and recreational clubs.';
        
        const liItem1 = document.createElement('li');
    liItem1.className = "chat incoming";
    liItem1.innerHTML = `<span class="material-symbols-outlined">smart_toy</span>
                    <p>${str}</p>`;
    maindiv.append(liItem1);
    }
    else if(value=='How can I contact the admissions office?'){
        var str = 'You can reach the admissions office at admissions@kiet.edu or call (123) 456-7890.';


        
        const liItem1 = document.createElement('li');
    liItem1.className = "chat incoming";
    liItem1.innerHTML = `<span class="material-symbols-outlined">smart_toy</span>
                    <p>${str}</p>`;
    maindiv.append(liItem1);
    }
    else if(value=='What clubs and organizations are available?'){
        var str = 'We have over 100 student organizations, including academic, cultural, and recreational clubs.';
        
        const liItem1 = document.createElement('li');
    liItem1.className = "chat incoming";
    liItem1.innerHTML = `<span class="material-symbols-outlined">smart_toy</span>
                    <p>${str}</p>`;
    maindiv.append(liItem1);
    }


    else{
        var str = 'Sorry I can not understand your query please enter the query acccording to given query list';
        
        const liItem1 = document.createElement('li');
    liItem1.className = "chat incoming";
    liItem1.innerHTML = `<span class="material-symbols-outlined">smart_toy</span>
    <p>${str}</p>`;
                    
    maindiv.append(liItem1);
    }
}