

// Simulate login functionality for demonstration purposes
/*function loginUser() {
    isLoggedIn = true; // Set login status to true
    alert("You are now logged in. Navbar links are enabled.");
}
// Initial login state
let isLoggedIn = false;

// Toggle dark/light theme
function toggleTheme() {
    document.body.classList.toggle("dark-theme");
    const themeIcon = document.getElementById("theme-icon");
    themeIcon.textContent = document.body.classList.contains("dark-theme") ? "🌙" : "🌞";
}

// Function to open a login prompt (placeholder)
function openLogin() {
    alert("Please log in to access this feature.");
}

// Display login message if not logged in
function checkLogin(event) {
    if (!isLoggedIn) {
        event.preventDefault(); // Prevent link action
        showMessage("Login to our site to access this feature.");
    }
}

// Show a styled message with animation
function showMessage(text) {
    const messageBox = document.getElementById("login-message");
    messageBox.textContent = text;
    messageBox.classList.add("show");
    setTimeout(() => {
        messageBox.classList.remove("show");
    }, 3000); // Hide after 3 seconds
}

// Simulate login for testing
function loginUser() {
    isLoggedIn = true;
    alert("You are now logged in. Navbar links are enabled.");
}*/



// Show info section on scroll
/*window.addEventListener("scroll", () => {
    const infoSection = document.getElementById("info-section");
    const scrollPosition = window.scrollY;
    if (scrollPosition > 200) { // Adjust this value as needed
        infoSection.style.display = "block";
        infoSection.classList.add("show");
    }
});*/


// Initial login state and credentials
let isLogedIn = false;
const validUsername = "riyagaur";
const validPassword = "riyu1212";

// Function to validate login
function loginUser(event) {
    event.preventDefault();
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    const loginError = document.getElementById("login-error");

    if (username === validUsername && password === validPassword) {
        isLogedIn = true;
        loginError.textContent = "";
        alert("You are now logged in! Navbar links are accessible.");
        document.getElementById("login-body").style.display = "none";
    } else {
        loginError.textContent = "Incorrect username or password. Please try again.";
    }
}

// Function to check login status for navbar access
function checkLogin(event) {
    if (!isLogedIn) {
        event.preventDefault(); // Prevent navigation
        showMessage("Login to our site to access this feature.");
    }
}

// Function to show message
function showMessage(text) {
    const messageBox = document.getElementById("login-message");
    messageBox.textContent = text;
    messageBox.classList.add("show");
    setTimeout(() => {
        messageBox.classList.remove("show");
    }, 3000); // Hide after 3 seconds
}


// Optional form validation
document.querySelector('.contact-form').addEventListener('submit', function(e) {
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;

    if (!name || !email || !message) {
        e.preventDefault();
        alert('Please fill out all fields!');
    }
});





