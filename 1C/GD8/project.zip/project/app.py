import subprocess
from flask import Flask, render_template

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")  # Load the homepage

@app.route("/run_pygame")
def run_pygame():
    # This will call your pygame script when triggered
    subprocess.Popen(["python", "pygame_script.py"])  # Adjust path to pygame_script.py if necessary
    return "Pygame application has started!"

if __name__ == "__main__":
    app.run(debug=True)
