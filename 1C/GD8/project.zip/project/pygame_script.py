import pygame
import heapq

pygame.init()

WIDTH, HEIGHT = 600, 600
ROWS, COLS = 30, 30
CELL_SIZE = WIDTH // ROWS

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREY = (200, 200, 200)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Pathfinding Visualizer")

def create_grid(rows, cols):
    grid = []
    for row in range(rows):
        grid.append([0] * cols)
    return grid

def draw_grid():
    for x in range(0, WIDTH, CELL_SIZE):
        pygame.draw.line(screen, GREY, (x, 0), (x, HEIGHT))
    for y in range(0, HEIGHT, CELL_SIZE):
        pygame.draw.line(screen, GREY, (0, y), (WIDTH, y))

def draw_cells(grid):
    for row in range(ROWS):
        for col in range(COLS):
            color = WHITE
            if grid[row][col] == 1:
                color = BLACK
            elif grid[row][col] == 2:
                color = RED
            elif grid[row][col] == 3:
                color = GREEN
            elif grid[row][col] == 4:
                color = BLUE
            elif grid[row][col] == 5:
                color = YELLOW
            pygame.draw.rect(screen, color, (col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE))

def get_grid_position(pos):
    x, y = pos
    return y // CELL_SIZE, x // CELL_SIZE

def heuristic(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])

def a_star(grid, start, end):
    open_set = []
    heapq.heappush(open_set, (0, start))
    came_from = {}
    g_score = {start: 0}
    f_score = {start: heuristic(start, end)}

    while open_set:
        _, current = heapq.heappop(open_set)

        if current == end:
            reconstruct_path(came_from, current, grid)
            return True

        neighbors = get_neighbors(current)
        for neighbor in neighbors:
            if grid[neighbor[0]][neighbor[1]] == 1:
                continue

            temp_g_score = g_score[current] + 1

            if neighbor not in g_score or temp_g_score < g_score[neighbor]:
                came_from[neighbor] = current
                g_score[neighbor] = temp_g_score
                f_score[neighbor] = temp_g_score + heuristic(neighbor, end)
                heapq.heappush(open_set, (f_score[neighbor], neighbor))

                if grid[neighbor[0]][neighbor[1]] != 3:
                    grid[neighbor[0]][neighbor[1]] = 5

    return False

def dijkstra(grid, start, end):
    open_set = []
    heapq.heappush(open_set, (0, start))
    came_from = {}
    g_score = {start: 0}

    while open_set:
        _, current = heapq.heappop(open_set)

        if current == end:
            reconstruct_path(came_from, current, grid)
            return True

        neighbors = get_neighbors(current)
        for neighbor in neighbors:
            if grid[neighbor[0]][neighbor[1]] == 1:
                continue

            temp_g_score = g_score[current] + 1

            if neighbor not in g_score or temp_g_score < g_score[neighbor]:
                came_from[neighbor] = current
                g_score[neighbor] = temp_g_score
                heapq.heappush(open_set, (g_score[neighbor], neighbor))

                if grid[neighbor[0]][neighbor[1]] != 3:
                    grid[neighbor[0]][neighbor[1]] = 5

    return False

def reconstruct_path(came_from, current, grid):
    while current in came_from:
        current = came_from[current]
        if grid[current[0]][current[1]] != 2:
            grid[current[0]][current[1]] = 4

def get_neighbors(pos):
    neighbors = []
    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    for direction in directions:
        row, col = pos[0] + direction[0], pos[1] + direction[1]
        if 0 <= row < ROWS and 0 <= col < COLS:
            neighbors.append((row, col))
    return neighbors

def main():
    grid = create_grid(ROWS, COLS)
    start, end = None, None
    running = True
    started = False

    while running:
        screen.fill(WHITE)
        draw_cells(grid)
        draw_grid()
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if pygame.mouse.get_pressed()[0]:  # Left click
                pos = pygame.mouse.get_pos()
                row, col = get_grid_position(pos)
                if not start:
                    start = (row, col)
                    grid[row][col] = 2
                elif not end:
                    end = (row, col)
                    grid[row][col] = 3
                else:
                    grid[row][col] = 1

            elif pygame.mouse.get_pressed()[2]:  # Right click
                pos = pygame.mouse.get_pos()
                row, col = get_grid_position(pos)
                if (row, col) == start:
                    start = None
                elif (row, col) == end:
                    end = None
                grid[row][col] = 0

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE and start and end and not started:
                    started = True
                    a_star(grid, start, end)

                if event.key == pygame.K_d and start and end and not started:
                    started = True
                    dijkstra(grid, start, end)

                if event.key == pygame.K_c:
                    grid = create_grid(ROWS, COLS)
                    start, end = None, None
                    started = False

    pygame.quit()

if __name__ == "__main__":
    main()
