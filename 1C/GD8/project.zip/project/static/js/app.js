document.getElementById("runPygameBtn").addEventListener("click", function() {
    fetch("/run_pygame")
        .then(response => response.text())
        .then(data => {
            alert(data);  // Alert the response from Flask
        })
        .catch(error => console.error("Error:", error));
});
