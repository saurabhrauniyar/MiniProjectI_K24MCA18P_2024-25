import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    items: [], //list of item in the cart
};

const wishSlice = createSlice({
    name: 'wishlist',
    initialState,
    reducers: {
        addToWishlist: (state,action)=>{
            const existingItem = state.items.find(item => item.id === action.payload.id);
            if(existingItem){
                existingItem.price += action.payload.price;
                // Agar item already wishlist mein hai to quantity update karo
                // existingItem.quantity += action.payload.quantity;
                // existingItem.subtotal = existingItem.quantity * existingItem.price;
            }
            else{
                console.log("Adding new item", action.payload)
                 // Agar item wishlist mein nahi hai to new item add karo
                 state.items.push({
                    ...action.payload,
                    price: action.payload.price,
                    // quantity: action.payload.quantity,  // Initial quantity set karo
                    // subtotal: action.payload.price * action.payload.quantity,  // Subtotal set karo

                });
            }
        },

        removeFromWishlist: (state,action)=>{
            state.items=state.items.filter(item=> item.id !== action.payload);
        }
        
    },
})

// export const selectCartTotal = (state) => state.cart.items.reduce((total, item)=> total + item.subtotal, 0);

export const {addToWishlist,removeFromWishlist} = wishSlice.actions;

export default wishSlice.reducer;