import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    items: [], //list of item in the cart
    total: 0,
};

const cartSlice = createSlice({
    name: 'cart',
    initialState,
    reducers: {
        addToCart: (state,action)=>{
            const existingItem = state.items.find(item => item.id === action.payload.id);
            if(existingItem){
                // Agar item already cart mein hai to quantity update karo
                existingItem.quantity += action.payload.quantity;
                existingItem.subtotal = existingItem.quantity * existingItem.price;
            }
            else{
                console.log("Adding new item", action.payload)
                 // Agar item cart mein nahi hai to new item add karo
                 state.items.push({
                    ...action.payload,
                    quantity: action.payload.quantity,  // Initial quantity set karo
                    subtotal: action.payload.price * action.payload.quantity,  // Subtotal set karo
                    // total: action.payload.price * action.payload.quanity,

                });
            }
        },

        removeFromCart: (state,action)=>{
            state.items=state.items.filter(item=> item.id !== action.payload);
        },
        // Clear Cart action
        clearCart: (state) => {
            state.items = [];
            state.total = 0;
        },

        updateQuantity: (state, action) => {
            // Update the quantity and subtotal for an item in the cart
            const item = state.items.find(item => item.id === action.payload.id);
            if (item) {
                console.log("Before update quantity: ", item.quantity);
                item.quantity = action.payload.quantity;
                item.subtotal = item.price * item.quantity;
                console.log("After update quantity: ", item.quantity);
            }
        }

        
    },
})

// export const selectCartTotal = (state) => state.cart.items.reduce((total, item)=> total + item.subtotal, 0);

export const {addToCart,removeFromCart,updateQuantity,clearCart} = cartSlice.actions;

export default cartSlice.reducer;