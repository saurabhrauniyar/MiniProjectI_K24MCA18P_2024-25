
import './Appstyle.css';
import './Responsive.css';
import Navbar from './Components/Navbar/Navbar';
import Banner from './Components/Banner/Banner';
import { useNavigate } from 'react-router-dom';
import Ourproducts from './Components/OurProducts/Ourproducts';
import Footer from './Components/Footer/Footer';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import axios from 'axios';
import Electronics from './Components/Product-Categ/Electronics';
import Furniture from './Components/Product-Categ/Furniture';
import Fashions from './Components/Product-Categ/Fashions';
import Fitness from './Components/Product-Categ/Fitness';
import ProductDetails from './Components/ProductDetails/ProductDetails';
import Cart from './Components/Cart/Cart';
import Wishlist from './Components/Wishlist/Wishlist';
import Login from './Components/Login/Login';
import Signup from './Components/Signup/Signup';
import Contact from './Components/Contact/Contact';
import About from './Components/About/About';
import Mobilemenu from './Components/Mobilemenu/Mobilemenu';
import { useSelector } from 'react-redux';
import { useState, useEffect } from 'react';

const App = () => {
    return (
        <BrowserRouter>
            <AppContent />
        </BrowserRouter>
    );
}

const AppContent = () => {
    const navigate = useNavigate();

    // Redux state se data fetch karna
    const cartItems = useSelector(state => state.cart.items);

    // Total quantity aur total price calculate karna
    const totalQuantity = cartItems.reduce((total, item) => total + item.quantity, 0);
    const totalPrice = cartItems.reduce((total, item) => total + item.subtotal, 0);

    const handleCartClick = () => {
        navigate('/cart'); //navigate to the cart page
    }

     // Track karna ki cart me item add hua hai ya nahi
     const [isUpdated, setIsUpdated] = useState(false);

     useEffect(() => {
            setIsUpdated(true);
            setTimeout(() => {
                setIsUpdated(false);
            }, 500); // Shake effect ke duration ke liye+
    }, [cartItems]);

    // Scroll to top when page loads
    useEffect(() => {
        window.scrollTo(0, 0); // Page ko top pe scroll karen
    }, []);

    const scrollToTop = () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    };
     
    return (
        <>
            <div>
                <Routes>
                    <Route path="/" element={<Navbar />} />
                    <Route path="/login" element={<Login />} />
                    <Route path="/signup" element={<Signup />} />
                    <Route path="/contact" element={<Contact />} />
                    <Route path="/about" element={<About />} />
                </Routes>
                <Routes>
                    <Route path="/" element={<Banner />} />
                </Routes>
                <Routes>
                    <Route path="/" element={<Ourproducts />} />
                </Routes>
                <Routes>
                    <Route path="/cart" element={<Cart />} />
                    <Route path="/electronics" element={<Electronics />} />
                    <Route path="/product-details" element={<ProductDetails />} />
                </Routes>
                <Routes>
                    <Route path="/furniture" element={<Furniture />} />
                </Routes>
                <Routes>
                    <Route path="/fashions" element={<Fashions />} />
                </Routes>
                <Routes>
                    <Route path="/wishlist" element={<Wishlist />} />
                    <Route path="/fitness" element={<Fitness />} />
                </Routes>
                <Routes>
                    <Route path="/" element={<Footer />} />
                </Routes>
                <Routes>
                    <Route path="/" element={<Mobilemenu />} />
                </Routes>
                
                

            </div>
            <div className={`cart-fixed text-ali ${isUpdated ? 'cart-shake' : ''}`} onClick={handleCartClick} style={{ cursor: 'pointer' }}>
                <h4 className='marg-tenpx'>My Cart</h4>
                <p className='marg-tenpx item-quantity bold'>{totalQuantity} items</p>
                <button className='marg-tenpx padd item-rs bold'>Rs. {totalPrice.toFixed(2)}</button>
            </div>

            <button onClick={scrollToTop} className="scroll-to-top-btn">
                ↑
            </button>
        </>
    )
}
export default App;

