import { Navigate, useLocation, useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import Navbar from "../Navbar/Navbar";
import Footer from "../Footer/Footer";
import './Cart.css';
import './CartRes.css';
import { useSelector, useDispatch } from "react-redux";
import { removeFromCart } from "../../cartSlice";
import { clearCart } from "../../cartSlice";
import { updateQuantity } from "../../cartSlice";
import Mobilemenu from "../Mobilemenu/Mobilemenu";

const Cart = () => {
    const [showMessage, setShowMessage] = useState(false);
    const [ClearcartMessage, setClearcartMessage] = useState(false);

    const handleIncrement = (id) => {
        const item = cartItems.find(item => item.id === id);
        if (item) {
            dispatch(updateQuantity({ id: item.id, quantity: item.quantity + 1 }));
        }
    };

    const handleDecrement = (id) => {
        const item = cartItems.find(item => item.id === id);
        if (item && item.quantity > 1) {
            dispatch(updateQuantity({ id: item.id, quantity: item.quantity - 1 }));
        }
    };

    // Function to calculate subtotal, ensuring no NaN value
    const calculateSubtotal = (price, quantity) => {
        return isNaN(price) || isNaN(quantity) ? 0 : price * quantity;
    };

    const calculateGrandTotal = () => {
        return cartItems.reduce((total, item) => {
            return total + (item.price * item.quantity);
        }, 0); // Initial total is 0
    };

    // Scroll to top when page loads
    useEffect(() => {
        window.scrollTo(0, 0); // Page ko top pe scroll karen
    }, []);


    const cartItems = useSelector(state => state.cart.items);
    const dispatch = useDispatch()

    const handleRemoveFromCart = (id) => {
        dispatch(removeFromCart(id));

        setShowMessage(true); // Message show karne ke liye state update
        setTimeout(() => {
            setShowMessage(false); // 3 seconds baad message ko hide karenge
        }, 3000);
    }

    const navigate = useNavigate();
    const handleLoginClick=()=>{
        navigate('/login')
    }

    const handleClearCart = () => {
        dispatch(clearCart());

        setClearcartMessage(true);  // Show the message
        setTimeout(() => {
            setClearcartMessage(false);  // Hide the message after 3 seconds
        }, 3000);
    }

    if (cartItems.length === 0) {
        return (
            <>
                <Navbar />
                <div className="container-cart">
                    <div id="row-cart" className="row-cart justify-cont align-cent text-ali">
                        <div className="col-12 col-m-12 col-m-6 col-t-12 col-IL-12 justify-cont align-cent text-ali">
                            <div className="title-text">
                                <h3>CART</h3>
                                <p className="mtfifteen fseighteen">Home / My Cart</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="container-cart">
                    {/* product-row */}
                    <div className="empty-box-row flex justify-cont align-cent">
                        <h2>Your cart is empty!</h2>
                    </div>
                    {/* Message-box */}
                    {
                        showMessage && (
                            <div className="message-box">
                                Your item is removed from the cart!
                            </div>
                        )
                    }
                    {/* clear-cart-message-box */}
                    {
                        ClearcartMessage && (
                            <div className="message-box">
                                Your cart is empty now!
                            </div>
                        )
                    }
                </div>
                <Footer />
                <Mobilemenu />
            </>
        );
    }
    return (
        <>
            <Navbar />
            <div className="container-cart">
                <div id="row-cart" className="row-cart justify-cont align-cent text-ali">
                    <div className="col-12 col-m-12 col-m-6 col-t-12 col-IL-12 justify-cont align-cent text-ali">
                        <div className="title-text">
                            <h3>CART</h3>
                            <p className="mtfifteen fseighteen">Home / My Cart</p>
                        </div>
                    </div>
                </div>
            </div>

            <div className="container-cart">
                {/* product-row */}
                <div className="row-cart justify-cont align-cent" id="row-cart2">
                    <div className="table-responsive">
                        <table className="table" cellSpacing="0">
                            <thead>
                                <tr className="thead-row">
                                    <td className="border-right">IMAGE</td>
                                    <td className="border-right">PRODUCT NAME</td>
                                    <td className="border-right">UNTIL PRICE</td>
                                    <td className="border-right">QTY</td>
                                    <td className="border-right">SUBTOTAL</td>
                                    <td>ACTION</td>
                                </tr>
                            </thead>
                            <tbody>

                                {cartItems.map(item => (
                                    <tr className="tbody-row" key={item.id}>
                                        <td className="border-right"><img src={item.image} alt={item.name} width="100px" /></td>
                                        <td className="border-right">{item.name}</td>
                                        <td className="border-right">{item.price}</td>
                                        <td className="border-right">
                                            <div className="flex quantity-btn align-cent mrgin">
                                                <button className="dec" onClick={() => handleDecrement(item.id)} >-</button>
                                                <input type="text" readOnly value={item.quantity} className="quantity-value" />
                                                <button className="inc" onClick={() => handleIncrement(item.id)}>+</button>
                                            </div>
                                        </td>
                                        <td className="border-right">{calculateSubtotal(item.price, item.quantity)}</td>
                                        <td>
                                            <button className="remove-btn" onClick={() => handleRemoveFromCart(item.id)}>Remove</button>
                                        </td>
                                    </tr>
                                ))}
                                <tr className="grand-total">
                                    <td colSpan="6">
                                        <div className="flex flex-end grand-total-div">
                                            <p>Grand Total:</p> &nbsp;&nbsp;&nbsp;&nbsp;
                                            <span>{calculateGrandTotal()} Rs.</span>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div className="row-cart btns align-cent space-bet" id="row-cart3">
                    <div className="flex col-6 col-p-12 col-t-12 col-k-12 col-m-12 coupn-col">
                        <input type="text" className="coupon-input" />
                        <button className="apply-coupon">APPLY COUPON</button>
                    </div>
                    <div className="flex col-6 col-p-12 col-t-12 col-m-12 col-k-12 clear-cart">
                        <button className="mr-thirty clear-cart-btn" onClick={handleClearCart}>CLEAR CART</button>
                        <button id="proceed-btn" onClick={handleLoginClick}>BUY NOW</button>
                    </div>
                </div>
            </div>

            {/* Message-box */}
            {
                showMessage && (
                    <div className="message-box">
                        Your item is removed from the cart!
                    </div>
                )
            }
            {/* clear-cart-message-box */}
            {
                ClearcartMessage && (
                    <div className="message-box">
                        Your cart is empty now!
                    </div>
                )
            }
            <Footer />
            <Mobilemenu />
        </>
    )
}

export default Cart;