import React from "react";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import './Navbar.css';
import './NavRes.css';
import { FaBars } from 'react-icons/fa';

const Navbar = () => {

    const navigate = useNavigate();
    const handleLoginClick=()=>{
        navigate('/login'); //navigate to the wishlist page
    }
    const handleContactClick=()=>{
        navigate('/contact'); //navigate to the wishlist page
    }
    const handleAboutClick=()=>{
        navigate('/about'); //naviagte to the about page
    }
    const handleWishlistClick=()=>{
        navigate('/wishlist'); //naviagte to the about page
    }
    const handleHomeClick=()=>{
        window.scrollTo({top: 0, behavior: "smooth" }); //scroll to top smooth
        navigate('/')
    }

    const [isMenuOpen, setIsMenuOpen] = useState(false); // State to control menu visibility

    const toggleMenu = () => {
        setIsMenuOpen(!isMenuOpen); // Toggle the menu visibility
        console.log("toggle click success")
    };

    return (
        <div className="container-first">
            <div className="nav-bar flex space-bet">
                <div className="col-2 col-t-12 col-p-12 col-m-12 flex align-cent web-name space-bet">
                    <h1 className="nav-main-heading" onClick={handleHomeClick}>MyShop</h1>
                        <div className="phn-btn menu">
                            <FaBars onClick={toggleMenu} style={{ fontSize: '24px', cursor: 'pointer', color: 'white' }} />
                        </div>
                </div>
                <div className={`col-10 col-t-12 col-p-12 col-m-12 flex align-cent colm-12 space-bet ul-column ${isMenuOpen ? "open" : "close"}`}>
                    <ul className="flex nav-ul justify-cont">
                        <li onClick={handleHomeClick}>Home</li>
                        <li onClick={handleAboutClick}>About</li>
                        <li onClick={handleContactClick}>Contacts</li>
                        <li onClick={handleLoginClick}>Sign-in</li>
                        <li onClick={handleWishlistClick}>Wishlist</li>
                    </ul>
                    
                    <div className="collapse2 flex">
                        <input type="text" className="search-txt" placeholder="Search..." />
                        <button className="search-btn">Search</button>
                    </div>
                </div>
            </div>
        </div>
    )
}


export default Navbar;

