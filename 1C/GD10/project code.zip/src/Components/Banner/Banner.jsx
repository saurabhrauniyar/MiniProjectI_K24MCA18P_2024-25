import React from 'react';
import './Banner.css';
import './BannerRes.css';

const Banner = () => {
    return (
        <div className='container-banner'>
            <div className="row-first banner-row">
                <div className="col-12 col-t-12 col-m-12 col-p-12 banner-col">
                    <h2>Welcome to <br /> MyShop</h2>
                    <div className='para'>
                        <p>Hello User! Welcome to our website.
                        "Our e-commerce website offers a seamless shopping experience with a variety of categories like Electronics, Furniture, Fashion, and Fitness designed to meet all your needs."
                        </p>
                    </div>
                    <button className='banner-btn'>Shop Now</button>
                </div>
            </div>
        </div>
    )
}

export default Banner;