import { useLocation } from "react-router-dom";
import { useEffect, useState } from "react";
import Navbar from "../Navbar/Navbar";
import Footer from "../Footer/Footer";
import './Wishlist.css';
import './WishlistRes.css';
import { useSelector, useDispatch } from "react-redux";
import { removeFromWishlist } from "../../wishSlice";
import { addToCart } from "../../cartSlice";
import { updateQuantity } from "../../cartSlice";
import { removeFromCart } from "../../cartSlice";
import Mobilemenu from "../Mobilemenu/Mobilemenu";

const Wishlist = () => {
    const [displayMessage, setDisplayMessage] = useState(false);
    const [showMessage, setShowMessage] = useState(false);
    const [quantity, setQuantity] = useState(1); // Default quantity 1

    // Scroll to top when page loads
    useEffect(() => {
        window.scrollTo(0, 0); // Page ko top pe scroll karen
    }, []);

    const scrollToTop = () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    };

    const cartItems = useSelector(state => state.cart.items);
    const wishlistItems = useSelector(state => state.wishlist.items);
    const [isInCart, setIsInCart] = useState(false);

    const dispatch = useDispatch()

    const handleRemoveFromWishlist = (id) => {
        dispatch(removeFromWishlist(id));

        setDisplayMessage(true); // Message show karne ke liye state update
        setTimeout(() => {
            setDisplayMessage(false); // 3 seconds baad message ko hide karenge
        }, 3000);
    }

    const handleAddToCart = (item) => {
        dispatch(addToCart({
            id: item.id,
            name: item.name,
            price: item.price,
            quantity: quantity,
            image: item.image,
        }));
        setIsInCart(true);
    };

    const handleRemoveFromCart = (item) => {
        dispatch(removeFromCart(item.id));
        setIsInCart(false);

        setShowMessage(true);  // Message show karna jab item cart se remove ho
        setTimeout(() => {
            setShowMessage(false);  // 3 second baad message ko hide karna
        }, 3000);
    };

    const handleButtonClick = (item) => {
        const itemInCart = cartItems.some((cartItem) => cartItem.id === item.id);
        if (itemInCart) {
            handleRemoveFromCart(item); //agar item cart me hai to remove chlao.
        } else {
            handleAddToCart(item); //agar item cart me nahi hai to add chlao.
        }
    };
    const getButtonText = (item) => {
        const itemInCart = cartItems.some((cartItem) => cartItem.id === item.id);
        return itemInCart ? "Remove" : "Add to cart";
    };
    
    // 2. Message ko show karne ka effect, jab cart mein item add ho
    useEffect(() => {
        if (isInCart) {
            setShowMessage(true); // Item cart mein add ho gaya, message show karo
            setTimeout(() => {
                setShowMessage(false); // 3 second baad message ko hide karo
            }, 3000);
        }
    }, [isInCart]); // Ye effect tab chalega jab isInCart ka value change ho

    if (wishlistItems.length === 0) {
        return (
            <>
                <Navbar />
                <div className="container-wishlist">
                    <div id="row-wishlist" className="row-wishlist justify-cont align-cent text-ali">
                        <div className="col-12 col-m-12 col-m-6 col-t-12 col-IL-12 justify-cont align-cent text-ali">
                            <div className="title-text">
                                <h3>WISHLIST</h3>
                                <p className="mtfifteen fseighteen">Home / Wishlist</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="container-wishlist">
                    {/* product-row */}
                    <div className="empty-box-row flex justify-cont align-cent">
                        <h2>Your wishlist is empty!</h2>
                    </div>
                    {/* Message-box */}
                    {
                        showMessage && (
                            <div className="message-box">
                                {isInCart ? "Your item is added to the cart!" : "Your item is removed from the cart!"}
                            </div>
                        )
                    }
                    {/* Message-box */}
                    {
                        displayMessage && (
                            <div className="message-box">
                                Your item is removed from the wishlist!
                            </div>
                        )
                    }
                </div>
                <Footer />
                <Mobilemenu />
            </>
        );
    }

    return (
        <>
            <Navbar />
            <div className="container-wishlist">
                <div id="row-wishlist" className="row-wishlist justify-cont align-cent text-ali">
                    <div className="col-12 col-m-12 col-m-6 col-t-12 col-IL-12 justify-cont align-cent text-ali">
                        <div className="title-text">
                            <h3>WISHLIST</h3>
                            <p className="mtfifteen fseighteen">Home / Wishlist</p>
                        </div>
                    </div>
                </div>
            </div>

            <div className="container-wishlist">
                {/* product-row */}
                <div className="row-wishlist justify-cont align-cent" id="row-wishlist2">
                    <div className="table-responsive">
                        <table className="table" cellSpacing="0">
                            <thead>
                                <tr className="thead-row">
                                    <td className="border-right">IMAGE</td>
                                    <td className="border-right">PRODUCT NAME</td>
                                    <td className="border-right">UNTIL PRICE</td>
                                    <td className="border-right">ADD TO CART</td>
                                    <td>ACTION</td>
                                </tr>
                            </thead>
                            <tbody>
                                {wishlistItems.map(item => (
                                    <tr className="tbody-row" key={item.id}>
                                        <td className="border-right"><img src={item.image} alt={item.image} width="100px" /></td>
                                        <td className="border-right">{item.name}</td>
                                        <td className="border-right">{item.price}</td>
                                        <td className="border-right">
                                            <button className="cart-btnn" onClick={()=> handleButtonClick(item)}>
                                                {getButtonText(item)}
                                            </button>
                                        </td>
                                        <td>
                                            <button className="remove-btn" onClick={() => handleRemoveFromWishlist(item.id)}>Remove</button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            {/* Message-box */}
            {
                showMessage && (
                    <div className="message-box">
                        {isInCart ? "Your item is added to the cart!" : "Your item is removed from the cart!"}
                    </div>
                )
            }
            {/* Message-box */}
            {
                displayMessage && (
                    <div className="message-box">
                        Your item is removed from wishlist!
                    </div>
                )
            }
            <button onClick={scrollToTop} className="scroll-to-top-btn">
                ↑
            </button>
            <Footer />
            <Mobilemenu />
        </>
    )
}

export default Wishlist;