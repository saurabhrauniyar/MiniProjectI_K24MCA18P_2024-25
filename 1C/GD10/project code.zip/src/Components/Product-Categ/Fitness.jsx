import React, { useState, useRef, useEffect } from "react";
import { useLocation } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import Navbar from "../Navbar/Navbar";
import Footer from "../Footer/Footer";
import './Fitness.css';
import './FitnessRes.css'
import Mobilemenu from "../Mobilemenu/Mobilemenu";

const Fitness = () => {
    const navigate = useNavigate();

    const handleProductClick =(product)=>{
        navigate("/product-details", {state: {product} });
    }

    const location = useLocation();
    const yogamats = location.state?.yogamats || [];
    const dumbells = location.state?.dumbells || [];
    const punchingbags = location.state?.punchingbags || [];
    const [selectedCategory, setSelectedCategory] = useState("Yoga Mats");
    console.log("Received items in Electronics:", yogamats);
    console.log("Received items in Electronics:", dumbells);
    console.log("Received items in Electronics:", punchingbags);


     // Shoes section ke liye reference create karein
     const dumbellsRef = useRef(null);
     const punchingbagsRef = useRef(null);
     const handleCategoryClick = (category) => {
         setSelectedCategory(category);

         if (category === "Dumbells" && dumbellsRef.current) {
            dumbellsRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
         else if (category === "Punching Bags" && punchingbagsRef.current) {
             punchingbagsRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
         }
     };
     useEffect(() => {
        if (selectedCategory === "Dumbells" && dumbellsRef.current) {
            dumbellsRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
        else if (selectedCategory === "Punching Bags" && punchingbagsRef.current) {
            punchingbagsRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }, [selectedCategory]);

    // Scroll to top when page loads
    useEffect(() => {
        window.scrollTo(0, 0); // Page ko top pe scroll karen
    }, []);

    const scrollToTop = () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    };

    return (
        <>
            <Navbar />
            <div className="container-fitness">
                <div className="row-fitness justify-cont align-cent text-ali">
                    <div className="col-12 col-m-12 col-m-6 col-t-12 col-IL-12">
                        <div className="title-txt">
                            <h3>FITNESS - PRODUCTS</h3>
                            <p>Home / Fitness</p>
                        </div>
                        <ul className="ul-categories flex">
                            {["Yoga Mats", "Dumbells", "Punching Bags"].map((category) => (
                                <li className="category-li"
                                    key={category}
                                    onClick={() => handleCategoryClick(category)}
                                    style={{
                                        padding: "15px 30px",
                                        cursor: "pointer",
                                        fontSize: "22px",
                                        color: selectedCategory === category ? "black" : "white",
                                        backgroundColor: selectedCategory === category ? "white" : "transparent",
                                        border: "2px solid white",
                                        margin: "10px 30px",
                                        borderRadius: "70px",
                                    }}
                                >
                                    {category.charAt(0).toUpperCase() + category.slice(1)}
                                </li>
                            ))}
                        </ul>
                    </div>

                </div>

                {/* Shirts-row */}
                {selectedCategory === "Yoga Mats" && (
                    <div>
                        <h3 className="category-name">YOGA MATS</h3>
                        <div className="product-rows">
                            {yogamats.map((yogamat, index) => (
                                <div key={index} className="col-data mats-col col-3 col-m-12 col-m-5 col-t-5 col-IL-4 text-ali" onClick={()=> handleProductClick(yogamat)}>
                                    <div>
                                        <p className="item-id">{yogamat.id}</p>
                                        <img src={yogamat.image} alt={yogamat.name} height="200" width="200" />
                                    </div>
                                    <div className="name-box">
                                        <h4 className="item-name">{yogamat.name}</h4>
                                    </div>
                                    <p className="item-price">Price: {"\u20B9"}{yogamat.price}</p>
                                </div>
                            ))}
                        </div>
                    </div>

                )}


                {/* Jeans-row */}
                {(selectedCategory === "Dumbells") && (
                    <div ref={dumbellsRef}>
                        <h3 className="category-name">DUMBELLS</h3>
                        <div className="product-rows">
                            {dumbells.map((dumbell, index) => (
                                <div key={index} className="col-data dumbells-col col-3 col-m-12 col-m-5 col-t-5 col-IL-4 text-ali" onClick={()=> handleProductClick(dumbell)}>
                                    <div>
                                        <p className="item-id">{dumbell.id}</p>
                                        <img src={dumbell.image} alt={dumbell.name} height="200" width="200" />
                                    </div>
                                    <div className="name-box">
                                        <h4 className="item-name">{dumbell.name}</h4>
                                    </div>
                                    <p className="item-price">Price: {"\u20B9"}{dumbell.price}</p>
                                </div>
                            ))}
                        </div>
                    </div>

                )}


                {/* Shoes-row */}
                {(selectedCategory === "Punching Bags") && (
                    <div ref={punchingbagsRef}>
                        <h3 className="category-name">PUNCHING BAG</h3>
                        <div className="product-rows">
                            {punchingbags.map((punchingbag, index) => (
                                <div key={index} className="col-data punching-col col-3 col-m-12 col-m-5 col-t-5 col-IL-4 text-ali" onClick={()=> handleProductClick(punchingbag)}>
                                    <div>
                                        <p className="item-id">{punchingbag.id}</p>
                                        <img src={punchingbag.image} alt={punchingbag.name} height="200" width="200" />
                                    </div>
                                    <div className="name-box">
                                        <h4 className="item-name">{punchingbag.name}</h4>
                                    </div>
                                    <p className="item-price">Price: {"\u20B9"}{punchingbag.price}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </div>
            <button onClick={scrollToTop} className="scroll-to-top-btn">
                ↑
            </button>
            <Footer />
            <Mobilemenu />
        </>
    )
}

export default Fitness;