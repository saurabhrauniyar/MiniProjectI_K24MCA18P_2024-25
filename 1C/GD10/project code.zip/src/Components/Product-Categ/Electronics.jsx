import React, { useState, useEffect, useRef } from "react";
import { useLocation } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import Navbar from "../Navbar/Navbar";
import Footer from "../Footer/Footer";
import './Electronics.css';
import './ElectronicsRes.css';
import ProductDetails from "../ProductDetails/ProductDetails";
import Mobilemenu from "../Mobilemenu/Mobilemenu";

const Electronics = () => {
    const navigate = useNavigate();

    const handleProductClick =(product)=>{
        navigate("/product-details", {state: {product} });
    }
    const location = useLocation();
    const items = location.state?.items || [];
    const cameraItems = location.state?.cameraItems || [];
    const headphoneItems = location.state?.headphoneItems || [];
    const [selectedCategory, setSelectedCategory] = useState("Smartphones");
    console.log("phone k item:", items);
    console.log("Received items in Electronics:", cameraItems);
    console.log("Received items in Electronics:", headphoneItems);

    // Shoes section ke liye reference create karein
    const camerasRef = useRef(null);
    const headphonesRef = useRef(null);
    const handleCategoryClick = (category) => {
        setSelectedCategory(category);

        if (category === "Cameras" && camerasRef.current) {
            camerasRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
        else if (category === "Headphones" && headphonesRef.current) {
            headphonesRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    };
    useEffect(() => {
        if (selectedCategory === "Cameras" && camerasRef.current) {
            camerasRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
        else if (selectedCategory === "Headphones" && headphonesRef.current) {
            headphonesRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }, [selectedCategory]);

    // Scroll to top when page loads
    useEffect(() => {
        window.scrollTo(0, 0); // Page ko top pe scroll karen
    }, []);

    const scrollToTop = () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    };

    return (
        <>
            <Navbar />
            <div className="container-electronics">
                <div className="row-electronics justify-cont align-cent text-ali">
                    <div className="col-12 col-m-12 col-m-6 col-t-12 col-IL-12 justify-cont align-cent text-ali">
                        <div className="title-txt">
                            <h3>ELECTRONICS - PRODUCTS</h3>
                            <p>Home / Electronics</p>
                        </div>
                        <ul className="ul-categories flex">
                            {["Smartphones", "Cameras", "Headphones"].map((category) => (
                                <li className="category-li"
                                    key={category}
                                    onClick={() => handleCategoryClick(category)}
                                    style={{
                                        padding: "15px 20px",
                                        cursor: "pointer",
                                        fontSize: "22px",
                                        color: selectedCategory === category ? "black" : "white",
                                        backgroundColor: selectedCategory === category ? "white" : "transparent",
                                        border: "2px solid white",
                                        margin: "15px 30px",
                                        borderRadius: "70px",
                                    }}
                                >
                                    {category.charAt(0).toUpperCase() + category.slice(1)}
                                </li>
                            ))}
                        </ul>
                    </div>
                </div>

                {/* mobile-row */}
                {selectedCategory === "Smartphones" && (
                    <div>
                        <h3 className="smartphone">SMARTPHONES</h3>
                        <div className="product-rows">
                            {items.map((item, index) => (
                                <div key={index} className="col-data col-3 col-m-12 col-m-5 col-t-5 col-IL-4 text-ali" onClick={()=> handleProductClick(item)}>
                                    <div>
                                        <p className="item-id">{item.id}</p>
                                        <img src={item.image} alt={item.name} height="200" width="200" />
                                    </div>
                                    <div className="name-box">
                                        <h4 className="item-name">{item.name}</h4>
                                    </div>
                                    <p className="item-price">Price: {"\u20B9"}{item.price}</p>
                                </div>
                            ))}
                        </div>
                    </div>

                )}


                {/* camera-row */}
                {(selectedCategory === "Cameras") && (
                    <div ref={camerasRef}>
                        <h3 className="smartphone">DSLR - CAMERAS</h3>
                        <div className="product-rows">
                            {cameraItems.map((camera, index) => (
                                <div key={index} className="col-data col-3 col-m-12 col-m-5 col-t-5 col-IL-4 text-ali" onClick={()=> handleProductClick(camera)}>
                                    <div>
                                        <p className="item.id">{camera.id}</p>
                                        <img src={camera.image} alt={camera.name} height="200" width="200" />
                                    </div>
                                    <div className="name-box">
                                        <h4 className="item-name">{camera.name}</h4>
                                    </div>
                                    <p className="item-price">Price: {"\u20B9"}{camera.price}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                )}


                {/* headphones-row */}
                {(selectedCategory === "Headphones") && (
                    <div ref={headphonesRef}>
                        <h3 className="smartphone">WIRELESS - HEADPHONES</h3>
                        <div className="product-rows">
                            {headphoneItems.map((headphone, index) => (
                                <div key={index} className="col-data col-3 col-m-12 col-m-5 col-t-5 col-IL-4 text-ali" onClick={()=> handleProductClick(headphone)}>
                                    <div>
                                        <p>{headphone.id}</p>
                                        <img src={headphone.image} alt={headphone.name} height="200" width="200" />
                                    </div>
                                    <div className="name-box">
                                        <h4 className="item-name">{headphone.name}</h4>
                                    </div>
                                    <p className="item-price">Price: {"\u20B9"}{headphone.price}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </div>
            <button onClick={scrollToTop} className="scroll-to-top-btn">
                ↑
            </button>
            <Footer />
            <Mobilemenu />
        </>
    )
}

export default Electronics;