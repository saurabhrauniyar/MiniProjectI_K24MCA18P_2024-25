import React, { useState, useRef, useEffect } from "react";
import { useLocation } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import Navbar from "../Navbar/Navbar";
import Footer from "../Footer/Footer";
import './Fashions.css';
import './FashionsRes.css'
import Mobilemenu from "../Mobilemenu/Mobilemenu";

const Fashions = () => {
    const navigate = useNavigate();

    const handleProductClick =(product)=>{
        navigate("/product-details", {state: {product} });
    }
    const location = useLocation();
    const shirts = location.state?.shirts || [];
    const jeans = location.state?.jeans || [];
    const shoes = location.state?.shoes || [];
    const [selectedCategory, setSelectedCategory] = useState("Shirts");
    console.log("Received items in Electronics:", shirts);
    console.log("Received items in Electronics:", jeans);
    console.log("Received items in Electronics:", shoes);


     // Shoes section ke liye reference create karein
     const jeansRef = useRef(null);
     const shoesRef = useRef(null);
     const handleCategoryClick = (category) => {
         setSelectedCategory(category);

         if (category === "Jeans" && jeansRef.current) {
            jeansRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
         else if (category === "Shoes" && shoesRef.current) {
             shoesRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
         }
     };
     useEffect(() => {
        if (selectedCategory === "Jeans" && jeansRef.current) {
            jeansRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
        else if (selectedCategory === "Shoes" && shoesRef.current) {
            shoesRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }, [selectedCategory]);

    // Scroll to top when page loads
    useEffect(() => {
        window.scrollTo(0, 0); // Page ko top pe scroll karen
    }, []);

    const scrollToTop = () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    };

    return (
        <>
            <Navbar />
            <div className="container-fashions">
                <div className="row-fashions justify-cont align-cent text-ali">
                    <div className="col-12 col-m-12 col-m-6 col-t-12 col-IL-12">
                        <div className="title-txt">
                            <h3>FASHIONS - PRODUCTS</h3>
                            <p>Home / Fashions</p>
                        </div>
                        <ul className="ul-categories flex">
                            {["Shirts", "Jeans", "Shoes"].map((category) => (
                                <li className="category-li"
                                    key={category}
                                    onClick={() => handleCategoryClick(category)}
                                    style={{
                                        padding: "15px 30px",
                                        cursor: "pointer",
                                        fontSize: "22px",
                                        color: selectedCategory === category ? "black" : "white",
                                        backgroundColor: selectedCategory === category ? "white" : "transparent",
                                        border: "2px solid white",
                                        margin: "10px 30px",
                                        borderRadius: "70px",
                                    }}
                                >
                                    {category.charAt(0).toUpperCase() + category.slice(1)}
                                </li>
                            ))}
                        </ul>
                    </div>

                </div>

                {/* Shirts-row */}
                {selectedCategory === "Shirts" && (
                    <div>
                        <h3 className="category-name">SHIRTS</h3>
                        <div className="product-rows">
                            {shirts.map((shirt, index) => (
                                <div key={index} className="col-data shirt-col col-3 col-m-12 col-m-5 col-t-5 col-IL-4 text-ali" onClick={()=> handleProductClick(shirt)}>
                                    <div>
                                        <p className="item-id">{shirt.id}</p>
                                        <img src={shirt.image} alt={shirt.name} height="200" width="200" />
                                    </div>
                                    <div className="name-box">
                                        <h4 className="item-name">{shirt.name}</h4>
                                    </div>
                                    <p className="item-price">Price: {"\u20B9"}{shirt.price}</p>
                                </div>
                            ))}
                        </div>
                    </div>

                )}


                {/* Jeans-row */}
                {(selectedCategory === "Jeans") && (
                    <div ref={jeansRef}>
                        <h3 className="category-name">JEANS</h3>
                        <div className="product-rows">
                            {jeans.map((jean, index) => (
                                <div key={index} className="col-data jeans-col col-3 col-m-12 col-m-5 col-t-5 col-IL-4 text-ali" onClick={()=> handleProductClick(jean)}>
                                    <div>
                                        <p className="item-id">{jean.id}</p>
                                        <img src={jean.image} alt={jean.name} height="200" width="200" />
                                    </div>
                                    <div className="name-box">
                                        <h4 className="item-name">{jean.name}</h4>
                                    </div>
                                    <p className="item-price">Price: {"\u20B9"}{jean.price}</p>
                                </div>
                            ))}
                        </div>
                    </div>

                )}


                {/* Shoes-row */}
                {(selectedCategory === "Shoes") && (
                    <div ref={shoesRef}>
                        <h3 className="category-name">SHOES</h3>
                        <div className="product-rows">
                            {shoes.map((shoe, index) => (
                                <div key={index} className="col-data col-3 col-m-12 col-m-5 col-t-5 col-IL-4 text-ali" onClick={()=> handleProductClick(shoe)}>
                                    <div>
                                        <p className="item-id">{shoe.id}</p>
                                        <img src={shoe.image} alt={shoe.name} height="200" width="200" />
                                    </div>
                                    <div className="name-box">
                                        <h4 className="item-name">{shoe.name}</h4>
                                    </div>
                                    <p className="item-price">Price: {"\u20B9"}{shoe.price}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </div>
            <button onClick={scrollToTop} className="scroll-to-top-btn">
                ↑
            </button>
            <Footer />
            <Mobilemenu />
        </>
    )
}

export default Fashions;