import React, { useState, useEffect, useRef } from "react";
import { useLocation } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import Navbar from "../Navbar/Navbar";
import Footer from "../Footer/Footer";
import './Furniture.css';
import './FurnitureRes.css';
import Mobilemenu from "../Mobilemenu/Mobilemenu";

const Furnitures = () => {
    const navigate = useNavigate();

    const handleProductClick =(product)=>{
        navigate("/product-details", {state: {product} });
    }

    const location = useLocation();
    const chairs = location.state?.chairs || [];
    const tables = location.state?.tables || [];
    const sofas = location.state?.sofas || [];
    const [selectedCategory, setSelectedCategory] = useState("Chairs");
    console.log("Chair's Items:", chairs);
    console.log("Table's:", tables);
    console.log("Sofa's:", sofas);

    // const handleCategoryClick = (category) => {
    //     setSelectedCategory(category);
    // };
    // Shoes section ke liye reference create karein
    const tablesRef = useRef(null);
    const sofasRef = useRef(null);
    const handleCategoryClick = (category) => {
        setSelectedCategory(category);

        if (category === "Tables" && tablesRef.current) {
           tablesRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
       }
        else if (category === "Sofas" && sofasRef.current) {
            sofasRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    };
    useEffect(() => {
       if (selectedCategory === "Tables" && tablesRef.current) {
           tablesRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
       }
       else if (selectedCategory === "Sofas" && sofasRef.current) {
           sofasRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
       }
   }, [selectedCategory]);

   // Scroll to top when page loads
   useEffect(() => {
       window.scrollTo(0, 0); // Page ko top pe scroll karen
   }, []);

   const scrollToTop = () => {
       window.scrollTo({
           top: 0,
           behavior: 'smooth'
       });
   };

    return (
        <>
            <Navbar />
            <div className="container-furnitures">
                <div className="row-furnitures justify-cont align-cent text-ali">
                    <div className="col-12 col-m-12 col-m-6 col-t-12 col-IL-12">
                        <div className="title-txt">
                            <h3>FURNITURES - PRODUCTS</h3>
                            <p>Home / Furnitures</p>
                        </div>
                        <ul className="ul-categories flex">
                            {["Chairs", "Tables", "Sofas"].map((category) => (
                                <li className="category-li"
                                    key={category}
                                    onClick={() => handleCategoryClick(category)}
                                    style={{
                                        padding: "15px 30px",
                                        cursor: "pointer",
                                        fontSize: "22px",
                                        color: selectedCategory === category ? "black" : "white",
                                        backgroundColor: selectedCategory === category ? "white" : "transparent",
                                        border: "2px solid white",
                                        margin: "10px 30px",
                                        borderRadius: "70px",
                                    }}
                                >
                                    {category.charAt(0).toUpperCase() + category.slice(1)}
                                </li>
                            ))}
                        </ul>
                    </div>

                </div>

                {/* Chair-row */}
                {selectedCategory === "Chairs" && (
                    <div>
                        <h3 className="category-name">CHAIRS</h3>
                        <div className="product-rows">
                            {chairs.map((chair, index) => (
                                <div key={index} className="col-data col-3 col-m-12 col-m-5 col-t-5 col-IL-4 text-ali" onClick={()=> handleProductClick(chair)}>
                                    <div>
                                        <p className="item-id">{chair.id}</p>
                                        <img src={chair.image} alt={chair.name} height="200" width="200" />
                                    </div>
                                    <div className="name-box">
                                        <h4 className="item-name">{chair.name}</h4>
                                    </div>
                                    <p className="item-price">Price: {"\u20B9"}{chair.price}</p>
                                </div>
                            ))}
                        </div>
                    </div>

                )}


                {/* Table-row */}
                {(selectedCategory === "Tables") && (
                    <div ref={tablesRef}>
                        <h3 className="category-name">TABLES</h3>
                        <div className="product-rows">
                            {tables.map((table, index) => (
                                <div key={index} className="col-data col-3 col-m-12 col-m-5 col-t-5 col-IL-4 text-ali" onClick={()=> handleProductClick(table)}>
                                    <div>
                                        <p className="item-id">{table.id}</p>
                                        <img src={table.image} alt={table.name} height="200" width="200" />
                                    </div>
                                    <div className="name-box">
                                        <h4 className="item-name">{table.name}</h4>
                                    </div>
                                    <p className="item-price">Price: {"\u20B9"}{table.price}</p>
                                </div>
                            ))}
                        </div>
                    </div>

                )}


                {/* Sofa-row */}
                {(selectedCategory === "Sofas") && (
                    <div ref={sofasRef}>
                        <h3 className="category-name">SOFAS</h3>
                        <div className="product-rows">
                            {sofas.map((sofa, index) => (
                                <div key={index} className="col-data col-3 col-m-12 col-m-5 col-t-5 col-IL-4 text-ali" onClick={()=> handleProductClick(sofa)}>
                                    <p className="item-id">{sofa.id}</p>
                                    <img src={sofa.image} alt={sofa.name} height="200" width="200" />
                                    <div className="name-box">
                                        <h4 className="item-name">{sofa.name}</h4>
                                    </div>
                                    <p className="item-price">Price: {"\u20B9"}{sofa.price}</p>
                                </div>
                            ))}
                        </div>
                    </div>

                )}
            </div>
            <button onClick={scrollToTop} className="scroll-to-top-btn">
                ↑
            </button>
            <Footer />
            <Mobilemenu />
        </>
    )
}

export default Furnitures;