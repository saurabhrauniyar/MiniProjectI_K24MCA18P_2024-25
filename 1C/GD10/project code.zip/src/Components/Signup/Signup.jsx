import { useLocation } from "react-router-dom";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../Navbar/Navbar";
import Footer from "../Footer/Footer";
import './Signup.css';
import './SignupRes.css';
import Mobilemenu from "../Mobilemenu/Mobilemenu";

const Signup = () => {
    const navigate = useNavigate();
    const LoginHandleClick = () => {
        navigate('/login'); //navigate to the wishlist page
    }

    // Scroll to top when page loads
    useEffect(() => {
        window.scrollTo(0, 0); // Page ko top pe scroll karen
    }, []);

    // State for form inputs and error messages
    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        password: '',
        confirmPassword: ''
    });
    const [errors, setErrors] = useState({});

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value
        });
    };

    // Form Validation function
    const validateForm = () => {
        const newErrors = {};

        // Check if fields are empty
        if (!formData.firstName) newErrors.firstName = "First name is required!";
        if (!formData.lastName) newErrors.lastName = "Last name is required!";

        // Validate email format
        const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        if (!formData.email){
            newErrors.email = "Email is required!";
        } 
        else if (!emailRegex.test(formData.email)){
            newErrors.email = "Please enter a valid email!";
        } 

        // Validate phone number format (E.164 format)
        const phoneRegex = /^\+?[1-9]\d{1,14}$/;
        if (!formData.phone){
            newErrors.phone = "Phone number is required!";
        } 
        else if (!phoneRegex.test(formData.phone)){
            newErrors.email = "Please enter a valid phone number!";
        } 

        // Validate password length
        if (!formData.password){
            newErrors.password = "Please enter the password!";
        }
        else if (formData.password.length < 6) {
            newErrors.password = "Password must be at least 6 characters long!";
        }

        // Validate confirm password
        if (formData.password !== formData.confirmPassword){
            newErrors.confirmPassword = "Passwords do not match!";
        } 

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0; // If no errors, return true
    };

    // Handle signup button click
    const handleSubmit = (e) => {
        e.preventDefault();
        if (validateForm()) {
            // Form is valid, proceed with signup (e.g., send data to API)
            console.log("Form Submitted", formData);
            navigate('/');
        }
    };

    return (
        <>
            <Navbar />
            <div className="container-signup">
                <div id="row-signup" className="row-signup justify-cont align-cent text-ali">
                    <div className="col-12 col-m-12 col-m-6 col-t-12 col-IL-12 justify-cont align-cent text-ali">
                        <div className="title-text">
                            <h3>CREATE ACCOUNT</h3>
                            <p className="mtfifteen fseighteen">Home / Sign Up</p>
                        </div>
                    </div>
                </div>
            </div>

            <div className="container-signup">
                <div className="row-signup justify-cont align-cent" id="row-signup2">
                    <div className="col-5 col-p-12 col-m-12 col-t-12 col-k-12 login-box flex">
                        <div className="flex space-bet name-input">
                            <div className="widthhalf">First Name * <input type="text" name="firstName" value={formData.firstName} onChange={handleInputChange}  />
                            {errors.firstName && <span className="error">{errors.firstName}</span>}
                            </div>

                            <div className="widthhalf">Last Name * <input type="text" name="lastName" value={formData.lastName} onChange={handleInputChange} />
                            {errors.lastName && <span className="error">{errors.lastName}</span>}
                            </div>
                        </div>

                        <div className="email">
                            Email * <br />
                            <input type="email" name="email" value={formData.email} onChange={handleInputChange}  />
                            {errors.email && <span className="error">{errors.email}</span>}
                        </div>

                        <div className="phone">
                            Phone * <br />
                            <input type="text" name="phone" placeholder="E.164 standard ex: +16135551111."  value={formData.phone} onChange={handleInputChange}  />
                            {errors.phone && <span className="error">{errors.phone}</span>}
                        </div>

                        <div className="password">
                            Password * <br />
                            <input type="password" name="password" value={formData.password} onChange={handleInputChange}  />
                            {errors.password && <span className="error">{errors.password}</span>}
                        </div>

                        <div className="password">
                            Confirm Password * <br />
                            <input type="password" name="confirmPassword" value={formData.confirmPassword} onChange={handleInputChange} />
                            {errors.confirmPassword && <span className="error">{errors.confirmPassword}</span>}
                        </div>
                        <button className="signup-btn" onClick={handleSubmit}>SIGNUP</button>
                        <button className="already-acc-btn" onClick={LoginHandleClick}>ALREADY HAVE &nbsp;A &nbsp;ACCOUNT?</button>
                    </div>
                </div>
            </div>
            <Footer />
            <Mobilemenu />
        </>
    )
}

export default Signup;