import { useLocation } from "react-router-dom";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Navbar from "../Navbar/Navbar";
import Footer from "../Footer/Footer";
// import './Electonics.css';
// import './ElectronicsRes.css';
import './ProductDetails.css';
import './ProDetailsRes.css';
import { useDispatch, useSelector } from "react-redux";
import { addToCart } from "../../cartSlice";
import { removeFromCart } from "../../cartSlice";
import { updateQuantity } from "../../cartSlice";
import { addToWishlist, removeFromWishlist } from "../../wishSlice";
import Mobilemenu from "../Mobilemenu/Mobilemenu";
import { FaFacebook } from "react-icons/fa";
import { FaTwitter } from "react-icons/fa";
import { FaLinkedin } from "react-icons/fa";



const ProductDetails = () => {
    const dispatch = useDispatch();
    const location = useLocation();
    const product = location.state?.product;

    const cartItems = useSelector(state => state.cart.items);
    const wishlistItems = useSelector(state => state.wishlist.items);

    const [showMessage, setShowMessage] = useState(false);
    const [displayMessage, setDisplayMessage] = useState(false);
    const [isInCart, setIsInCart] = useState(false);
    const [isInWishlist, setIsInWishlist] = useState(false);
    const [quantity, setQuantity] = useState(1); // Default quantity 1

    if (!product) {
        return <div>No Product Details Found</div>;
    }

    const handleAddToCart = () => {
        dispatch(addToCart({
            id: product.id,
            name: product.name,
            price: product.price,
            quantity: quantity,
            image: product.image,
        }));
        setIsInCart(true);
    };

    const handleRemoveFromCart = () => {
        dispatch(removeFromCart(product.id));
        setIsInCart(false);

        setShowMessage(true);  // Message show karna jab item cart se remove ho
        setTimeout(() => {
            setShowMessage(false);  // 3 second baad message ko hide karna
        }, 3000);
    };

    const handleAddToWishlist = () => {
        dispatch(addToWishlist({
            id: product.id,
            name: product.name,
            price: product.price,
            image: product.image,
        }));
        setIsInWishlist(true);
    };
    const handleRemoveFromWishlist = () => {
        dispatch(removeFromWishlist(product.id));
        setIsInWishlist(false);

        setDisplayMessage(true);  // Message show karna jab item cart se remove ho
        setTimeout(() => {
            setDisplayMessage(false);  // 3 second baad message ko hide karna
        }, 3000);
    };

    const handleButtonClick = () => {
        if (isInCart) {
            handleRemoveFromCart(); //agar item cart me hai to remove chlao.
        } else {
            handleAddToCart(); //agar item cart me nahi hai to add chlao.
        }
    };

    const handleBtnTwoClick = () => {
        if (isInWishlist) {
            handleRemoveFromWishlist(); //agar item wishlist me hai to remove chlao.
        } else {
            handleAddToWishlist(); //agar item wishlist me nahi hai to add chlao.
        }
    }

    const getButtonText = () => {
        return isInCart ? "Remove from cart" : "Add to cart";
    };

    const getButtonTextTwo = () => {
        return isInWishlist ? "Remove from wishlist" : "Add to wishlist";
    };

    const handleIncrement = () => {
        setQuantity(prevQuantity => {
            const newQuantity = prevQuantity + 1;
            dispatch(updateQuantity({ id: product.id, quantity: newQuantity }));
            return newQuantity;
        });
    };

    const handleDecrement = () => {
        if (quantity > 1) {
            setQuantity(prevQuantity => {
                const newQuantity = prevQuantity - 1;
                dispatch(updateQuantity({ id: product.id, quantity: newQuantity }));
                return newQuantity;
            });
        }
    };




    // Check if the product is in the cart on initial load or when cartItems change
    useEffect(() => {
        const itemInCart = cartItems.some((item) => item.id === product.id);
        setIsInCart(itemInCart);
    }, [cartItems, product.id]); // Re-run when `cartItems` or `product.id` change

    // Check if the product is in the cart on initial load or when cartItems change
    useEffect(() => {
        const itemInWishlist = wishlistItems.some((item) => item.id === product.id);
        setIsInWishlist(itemInWishlist);
    }, [wishlistItems, product.id]); // Re-run when `cartItems` or `product.id` change


    // 2. Message ko show karne ka effect, jab cart mein item add ho
    useEffect(() => {
        if (isInCart) {
            setShowMessage(true); // Item cart mein add ho gaya, message show karo
            setTimeout(() => {
                setShowMessage(false); // 3 second baad message ko hide karo
            }, 3000);
        }
    }, [isInCart]); // Ye effect tab chalega jab isInCart ka value change ho

    useEffect(() => {
        if (isInWishlist) {
            setDisplayMessage(true); // Item cart mein add ho gaya, message show karo
            setTimeout(() => {
                setDisplayMessage(false); // 3 second baad message ko hide karo
            }, 3000);
        }
    }, [isInWishlist]); // Ye effect tab chalega jab isInCart ka value change ho

    // Scroll to top when page loads
    useEffect(() => {
        window.scrollTo(0, 0); // Page ko top pe scroll karen
    }, []);

    return (
        <>
            <Navbar />
            <div className="container-prodetails">
                <div id="row-prodetails" className="row-prodetails justify-cont align-cent text-ali">
                    <div className="col-12 col-m-12 col-m-6 col-t-12 col-IL-12 justify-cont align-cent text-ali">
                        <div className="title-text">
                            <h3>{product.name}</h3>
                            <p className="mtfifteen fseighteen">Home / OurProducts</p>
                        </div>
                    </div>
                </div>
            </div>

            <div className="container-prodetails">
                {/* product-row */}
                <div className="row-prodetails justify-cont align-cent" id="prodetails2">
                    <div className="col-4 col-m-12 col-m-6 col-p-12 col-t-12 col-IL-12 justify-cont align-cent flex">
                        <div>
                            <p className="item-id">{product.id}</p>
                            <img src={product.image} alt={product.name} height="400" className="product-img" />
                        </div>
                    </div>
                    <div className="col-8 product-content col-m-12 col-p-12 col-t-12 col-IL-12 justify-cont align-cent prod-details-col">
                        {/* <p><strong>SKU:</strong> 1510</p> */}
                        <p className="mtten"><strong>Availability:</strong> 1 in stock</p>
                        <h3 className="mtfifteen">{product.name}</h3>
                        <h4 className="mtten">{"\u20B9"}{product.price}</h4>
                        <div className="mtfifteen description-div">
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae, culpa sed nostrum quo sunt nihil odit aliquam, magnam labore similique voluptate cupiditate. Aut deserunt alias nulla.</p>
                        </div>
                        <div className="flex buttons-div mtfifteen">
                            <div className="flex quantity-btn align-cent">
                                <button className="dec" onClick={handleDecrement}>-</button>
                                <input type="text" readOnly value={quantity} className="quantity-value" />
                                <button className="inc" onClick={handleIncrement}>+</button>
                            </div>
                            <button className="cart-butn" onClick={handleButtonClick}>
                                {getButtonText()}
                            </button>
                        </div>
                        <button className="wishlist-btn mtfifteen" onClick={handleBtnTwoClick}>
                            {getButtonTextTwo()}
                        </button>
                        <p className="share mtfifteen"><strong>Share:</strong>
                            <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer">
                                <FaFacebook className="social-icon" />
                            </a> &nbsp;&nbsp;

                            <a href="https://twitter.com" target="_blank" rel="noopener noreferrer">
                                <FaTwitter className="social-icon" />
                            </a> &nbsp;&nbsp;

                            <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer">
                                <FaLinkedin className="social-icon" />
                            </a>

                        </p>
                    </div>
                </div>
            </div>

            {/* Message-box */}
            {
                showMessage && (
                    <div className="message-box">
                        {isInCart ? "Your item is added to the cart!" : "Your item is removed from the cart!"}
                    </div>
                )
            }
            {
                displayMessage && (
                    <div className="message-box">
                        {isInWishlist ? "Your item is added to the wishlist!" : "Your item is removed from the wishlist!"}
                    </div>
                )
            }
            <Footer />
            <Mobilemenu />
        </>
    );
}
export default ProductDetails;