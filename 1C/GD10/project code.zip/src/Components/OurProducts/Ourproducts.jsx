import React from "react"
import axios from "axios";
import { useState, useEffect } from "react";
import './Ourproducts.css';
import './OurprodRes.css';
// import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import Electronics from "../Product-Categ/Electronics";
import Furniture from "../Product-Categ/Furniture";
import Fashions from "../Product-Categ/Fashions";
import Fitness from "../Product-Categ/Fitness";



const Ourproducts = () => {
    const [items, setItems] = useState([]);
    const [cameraItems, setCameraItems] = useState([]); 
    const [headphoneItems, setHeadphoneItems] = useState([]);

    const [chairs, setChairs] = useState([]);
    const [tables, setTables] = useState([]); 
    const [sofas, setSofas] = useState([]); 

    const [shirts, setShirts] = useState([]);
    const [jeans, setJeans] = useState([]); 
    const [shoes, setShoes] = useState([]); 

    const [yogamats, setYogamats] = useState([]);
    const [dumbells, setDumbells] = useState([]); 
    const [punchingbags, setPunchingbags] = useState([]); 
    const navigate = useNavigate();

    const handleExploreClick = () => {
        navigate('/electronics', { state: { items, cameraItems, headphoneItems } });
    }
    const handleFurnitureClick = () =>{
        navigate('/furniture', { state: { chairs, tables, sofas } });
    }
    const handleFashionsClick = () =>{
        navigate('/fashions', { state: { shirts, jeans, shoes } });
    }
    const handleSportsClick = () =>{
        navigate('/fitness', { state: { yogamats, dumbells, punchingbags } });
    }
    useEffect(() => {
        axios.get('https://6707d6b38e86a8d9e42d2378.mockapi.io/items')

            .then(response => {
                // Define custom Images, names & Prices

                //1.ELECTRONICS-ITEMS
                const customIds=[
                    "smartphone-1","smartphone-2","smartphone-3","smartphone-4","smartphone-5","smartphone-6" 
                ]
                const customImages = [
                    "https://m.media-amazon.com/images/I/61l9ppRIiqL._SX679_.jpg", 
                    "https://m.media-amazon.com/images/I/71IfBk7ET0L._SL1500_.jpg",
                    "https://m.media-amazon.com/images/I/61bK6PMOC3L._SL1500_.jpg", "https://m.media-amazon.com/images/I/71oWrfCTiqL._SX679_.jpg", 
                    "https://m.media-amazon.com/images/I/71lD7eGdW-L._SL1500_.jpg",
                    "https://m.media-amazon.com/images/I/81T3olLXpUL._SL1500_.jpg"
                ]

                const customNames = [
                    "Apple iPhone 13 (128GB) - Pink",
                    "Samsung Galaxy S24 5G AI",
                    "Apple iPhone 14 (128 GB) - Purple",
                    "Apple iPhone 16 Plus (128 GB) - Ultramarine",
                    "Samsung Galaxy S23 Ultra 5G AI", "Samsung Galaxy M05 (Mint Green)"
                ];

                const customPrices = [
                    "45,499", "62,999", "66,900", "86,900",
                    "79,999", "7,999"
                ];

                const cameraIds = [
                    "camera-1","camera-2","camera-3","camera-4","camera-5","camera-6"
                ]
                const cameraImages = [
                    "https://m.media-amazon.com/images/I/81WtQ64-SOL._SL1500_.jpg", 
                    "https://m.media-amazon.com/images/I/71BtxnjY0aL._SL1000_.jpg",
                    "https://m.media-amazon.com/images/I/61QoynZYblL._SL1000_.jpg",
                    "https://m.media-amazon.com/images/I/91xnO7qHAeL._SL1500_.jpg",
                    "https://m.media-amazon.com/images/I/91qUqC4Z8hL._SL1500_.jpg",
                    "https://m.media-amazon.com/images/I/81C9A0E+8TL._SL1500_.jpg"
                ];
                const cameraNames = [
                    "Nikon D850 45.7MP Digital SLR Camera", 
                    "Fujifilm X-T4 26 MP Mirrorless Camera",
                    "Canon EOS R7 32.5MP Mirrorless Camera",
                    "Panasonic LUMIX G7 16.00 MP 4K Mirrorless Camera",
                    "Nikon Mirrorless Z fc Body",
                    "KODAK PIXPRO AZ405-BK 20MP Digital Camera",
                ];
                const cameraPrices = [
                    "2,69,955", "43,990", "1,85,998", "42,489", "94,490", "25,147"
                ];

                const headphoneIds=[
                    "headphone-1","headphone-2","headphone-3","headphone-4","headphone-5","headphone-6"
                ]
                const headphoneImages = [
                    "https://m.media-amazon.com/images/I/61XuLr92V3L._SL1500_.jpg", 
                    "https://m.media-amazon.com/images/I/61LXdoeSvbL._SL1500_.jpg",
                    "https://m.media-amazon.com/images/I/51FNnHjzhQL._SL1200_.jpg",
                    "https://m.media-amazon.com/images/I/41JACWT-wWL._SL1200_.jpg",
                    "https://m.media-amazon.com/images/I/61wbr2lSdJL._SL1500_.jpg",
                    "https://m.media-amazon.com/images/I/618-45t0P5L._SL1500_.jpg"
                ];
                const headphoneNames = [
                    "Noise 3 Wireless On-Ear Headphones", 
                    "HAMMER Bash Wireless Bluetooth Headphones",
                    "boAt Rockerz 450 Bluetooth Headphones",
                    "Sony WH-CH520, Wireless Bluetooth Headphones",
                    "Srhythm NC25 Wireless Headphones Bluetooth 5.3",
                    "ZEBRONICS THUNDER Bluetooth 5.3 Wireless Headphones",
                ];
                const headphonePrices = [
                    "1,999", "2,499", "2,099", "4,212", "7,599", 
                    "799"
                ];

                //FURNITURE-ITEMS
                const chairIds = [
                    "chair-1","chair-2","chair-3","chair-4","chair-5","chair-6"
                ]
                const chairImages = [
                    "https://m.media-amazon.com/images/I/61Uc+EKCHRL.jpg",
                    "https://m.media-amazon.com/images/I/71MB1YTFxxL._SL1500_.jpg",
                    "https://m.media-amazon.com/images/I/71SDhq57D-L._SL1500_.jpg",
                    "https://m.media-amazon.com/images/I/81r2k3CH5YL._SL1500_.jpg",
                    "https://m.media-amazon.com/images/I/91Yj1akCoeL._SL1500_.jpg",
                    "https://m.media-amazon.com/images/I/91Yj1akCoeL._SL1500_.jpg"
                ];
                const chairNames = [
                    "Md Decor Solid Sheesham Wood Arm Chair",
                    "Vinod Handicraft Sheesham Wood Arm Chair",
                    "Vergo Plush Dining Chair | Accent Chair",
                    "Medieval Arts Stelley Chair (Rosewood, Brown)",
                    "Solimo Alore Solid Sheesham Wood Arm Chair",
                    "Solimo Alore Solid Sheesham Wood Arm Chair"
                ];
                const chairPrices =[
                    "4,697", "4,399", "6,990", "8,999", "6,399", "6,399"
                ];

                const tableIds = [
                    "table-1","table-2","table-3","table-4","table-5","table-6"
                ]
                const tableImages = [
                    "https://m.media-amazon.com/images/I/81YMBfSrFuL._SL1500_.jpg",
                    "https://m.media-amazon.com/images/I/91yD7jbDXvL._SL1500_.jpg",
                    "https://m.media-amazon.com/images/I/913yA2UL2qL._SL1500_.jpg",
                    "https://m.media-amazon.com/images/I/81tXNIEOJ0L._SL1200_.jpg",
                    "https://m.media-amazon.com/images/I/71cjrg7mFrL._SL1200_.jpg",
                    "https://m.media-amazon.com/images/I/71cjrg7mFrL._SL1200_.jpg"
                ];
                const tableNames = [
                    "Solimo Acamar Solid Sheesham Wood Coffee Table ",
                    "Portable Wooden Centre Table with Storage & Open Rack",
                    "Engineered Wood Contemporary Walnut Finish Coffee Table",
                    "Wood Painted Natural Wood Finish Coffee Table",
                    "DecorNation Derby Engineered Wood Coffee Table",
                    "DecorNation Derby Engineered Wood Coffee Table"
                ];
                const tablePrices =[
                    "15,399", "2,999", "2,439", "3,525", "12,999","12,999"
                ];

                const sofaIds = [
                    "sofa-1","sofa-2","sofa-3","sofa-4","sofa-5","sofa-6"
                ]
                const sofaImages = [
                    "https://m.media-amazon.com/images/I/71g9dhjpdgL._SL1500_.jpg",
                    "https://m.media-amazon.com/images/I/71CZtDCP3uL._SL1420_.jpg",
                    "https://m.media-amazon.com/images/I/71mrVuraMHL._SL1500_.jpg",
                    "https://m.media-amazon.com/images/I/61T+3l+c7jL._SL1100_.jpg",
                    "https://m.media-amazon.com/images/I/81DK+EzVN8L._SL1500_.jpg",
                    "https://m.media-amazon.com/images/I/81DK+EzVN8L._SL1500_.jpg"
                ];
                const sofaNames = [
                    "wakeup INDIA Sofa | Mushy Premium Fabric Sofa Set ",
                    "Home Centre Pine Wood Berry 2 Seater Sofa ",
                    "Three Seater Aspen Recliner Couch Wooden Frame Sofa",
                    "3 Seater Fabric Sofa Set for Living Room Furniture",
                    "Foldable Sofa Cums Bed-Blue Color for Living Bedroom",
                    "Foldable Sofa Cums Bed-Blue Color for Living Bedroom"
                ];
                const sofaPrices =[
                    "17,999", "12,999", "15,199", "9,999", "6,934","6,399"
                ];
                
                //FASHIONS-ITEMS
                const shirtIds = [
                    "shirt-1","shirt-2","shirt-3","shirt-4","shirt-5","shirt-6"
                ];
                const shirtImages = [
                    "https://m.media-amazon.com/images/I/71quo5VvAFL._SY879_.jpg",
                    "https://m.media-amazon.com/images/I/81uTb5UwUgL._SY879_.jpg",
                    "https://m.media-amazon.com/images/I/61EI6XrupYL._SY879_.jpg",
                    "https://m.media-amazon.com/images/I/61nuKbdXEoL._SY879_.jpg",
                    "https://m.media-amazon.com/images/I/51kZUzGL6IL.jpg",
                    "https://m.media-amazon.com/images/I/61gRTddtw6L._SY879_.jpg"
                ];
                const shirtNames = [
                    "INKAST Men's Slim Fit Casual Shirt",
                    "Miraan Men's Casual Denim Shirt",
                    "Men Checkered Cotton Casual Shirt",
                    "Boys Long Sleeve Collared Neck Shirt",
                    "Men's Cotton Casual Striped Shirt",
                    "Purple and White Men Short Sleeve Shirt "
                ];
                const shirtPrices =[
                    "889", "927", "1,195", "1,799", "2,199", "999"
                ];

                const jeanIds = [
                    "jean-1","jean-2","jean-3","jean-4","jean-5","jean-6"
                ]
                const jeanImages = [
                    "https://m.media-amazon.com/images/I/71gHEC8+QJL._SY879_.jpg",
                    "https://m.media-amazon.com/images/I/71QwN7BmaDL._SY879_.jpg",
                    "https://m.media-amazon.com/images/I/613hmtm815L._SY879_.jpg",
                    "https://m.media-amazon.com/images/I/81BxliokD0L._SY879_.jpg",
                    "https://m.media-amazon.com/images/I/61EITRMkVTL._SY879_.jpg",
                    "https://m.media-amazon.com/images/I/518VApMhUsL._SY879_.jpg"
                ];
                const jeanNames = [
                    "Lymio Men's Loose Baggy Jeans",
                    " Denim Jeans || Baggy Jeans for Men",
                    "GRECIILOOKS Jeans for Men ",
                    "Men Cargo Jeans Sky Blue",
                    "Denim Tapered Fit Carrot Jeans",
                    "Men's Black Regular Fit Denim Jeans"
                ];
                const jeanPrices =[
                    "2,399", "1,999", "3,439", "1,525", "1,399","2,599"
                ];

                const shoeIds = [
                    "shoe-1", "shoe-2", "shoe-3", "shoe-4", "shoe-5", "shoe-6"
                ]
                const shoeImages = [
                    "https://m.media-amazon.com/images/I/61jzjuPckrL._SY695_.jpg",
                    "https://m.media-amazon.com/images/I/61VzAAvV6RL._SY695_.jpg",
                    "https://m.media-amazon.com/images/I/61McbaOnicL._SY695_.jpg",
                    "https://m.media-amazon.com/images/I/61PpFJioX3L._SY695_.jpg",
                    "https://m.media-amazon.com/images/I/51Cs+xUnFNL._SY695_.jpg",
                    "https://m.media-amazon.com/images/I/71q1kvs1xJL._SY695_.jpg"
                ];
                const shoeNames = [
                    "Red Tape Casual Sneakers",
                    "Sparx Men's Canvas Sneakers",
                    "Campus Camp Torque Casual Sneakers",
                    "Centrino Mens 6006 Casual Sneakers",
                    "Puma Men's Coarse Running Shoe",
                    "Red Tape Athleisure Shoes for Men"
                ];
                const shoePrices =[
                    "1,919", "714", "1,799", "1,299", "2,249","3,269"
                ];

                //FITNESS-ITEMS
                const yogamatIds = [
                    "mat-1","mat-2","mat-3","mat-4","mat-5","mat-6"
                ]
                const yogamatImages = [
                    "https://m.media-amazon.com/images/I/817n+-aD8uL._SL1500_.jpg",
                    "https://m.media-amazon.com/images/I/61dYsZwAtQL._SL1500_.jpg",
                    "https://m.media-amazon.com/images/I/617gCKmEkJL._SL1200_.jpg",
                    "https://m.media-amazon.com/images/I/71EwiCsQeTL._SL1500_.jpg",
                    "https://m.media-amazon.com/images/I/71Kp8RB2-uL._SL1500_.jpg",
                    "https://m.media-amazon.com/images/I/81wvPXmY45L._SL1500_.jpg"
                ];
                const yogamatNames = [
                    "Boldfit Yoga Mat for Women and Men",
                    "Bodyband Yoga Mat for Women and Men",
                    "Boldfit Yoga Mats NBR Material",
                    "Bodylastics Yoga Mat for Men and Women",
                    "HealthSense Yoga Mat for Women & Men",
                    "Dr Trust TPE Premium Luxfoam Yoga Mat "
                ];
                const yogamatPrices =[
                    "2,499", "597", "1,899", "1,329", "3,299", "1,189"
                ];

                const dumbellIds = [
                    "dumbell-1","dumbell-2","dumbell-3","dumbell-4","dumbell-5","dumbell-6"
                ]
                const dumbellImages = [
                    "https://m.media-amazon.com/images/I/61v1qbflxoL._SL1500_.jpg",
                    "https://m.media-amazon.com/images/I/7153TF65MgL._SL1500_.jpg",
                    "https://m.media-amazon.com/images/I/711XOGZFEoL._SL1500_.jpg",
                    "https://m.media-amazon.com/images/I/71hinuBiLzL._SL1500_.jpg",
                    "https://m.media-amazon.com/images/I/815mlqNm1hL._SL1500_.jpg",
                    "https://m.media-amazon.com/images/I/61mUc9vBJqL._SL1500_.jpg"
                    
                ];
                const dumbellNames = [
                    "Lifelong Iron Single Adjustable Dumbbells",
                    "Symactive Rubber Coated 5 Kg Bouncer Dumbbells",
                    "Sportneer Dumbbells Set For Home Gym",
                    "Symactive Rubber Professional Dumbbells | 12.5 kg",
                    "SLOVIC Dumbbells Set for Home Gym | 7.5 kg",
                    "RUBX Rubber Professional Hex Dumbbells | 5 kg"
                ];
                const dumbellPrices =[
                  "5,999", "1,279","3,499","3,379", "2,399", "3,439"
                ];
                const punchingbagImages = [
                    "https://m.media-amazon.com/images/I/61nosdcq13L._SL1500_.jpg",
                    "https://m.media-amazon.com/images/I/51CsffI+GsL._SL1500_.jpg",
                    "https://m.media-amazon.com/images/I/61RfLzcTm5L._SL1500_.jpg",
                    "https://m.media-amazon.com/images/I/61yrv7EJM7L._SL1500_.jpg",
                    "https://m.media-amazon.com/images/I/51-aqBUa9IL._SL1143_.jpg",
                    "https://m.media-amazon.com/images/I/514BLFV2DaL._SL1499_.jpg"
                ];

                const punchingbagIds = [
                    "bag-1","bag-2","bag-3","bag-4","bag-5","bag-6"
                ]
                const punchingbagNames = [
                    "Aurion Synthetic Leather Filled Punching Bag",
                    "Invincible Classic Vinyl Never Tear Punching Bag",
                    "HRX 3ft Unfilled Punching Bag",
                    "RMOUR Unfilled Black Heavy PU Punch Bag Boxing",
                    "VICTORY Heavy Synthetic Leather Punching Bag ",
                    "USI UNIVERSAL THE UNBEATABLE Boxing Punching Bag"
                ];
                const punchingbagPrices =[
                   "2,049", "5,899", "3,369","4,350", "1,789", "2,879" 
                ];
                


                //UPDATE ELECTRONICS ITEMS:- images,names,prices
                // Update camera items with custom names
                const updatedItems = response.data.map((item, index) => {
                    const customId = customIds[index % customIds.length];
                    const customName = customNames[index % customNames.length];
                    const customPrice = customPrices[index % customPrices.length];
                    const customImage = customImages[index % customImages.length];

                    return { ...item, id:customId, name: customName, price: customPrice, image: customImage }; // Assign custom name
                });

                // Update cameraItems with the second set of custom data
                const updatedCameraItems = response.data.map((item, index) => {
                    return {
                        ...item,
                        id: cameraIds[index % cameraIds.length],
                        name: cameraNames[index % cameraNames.length],
                        price: cameraPrices[index % cameraPrices.length],
                        image: cameraImages[index % cameraImages.length],
                    };
                });

                // Update HeadphoneItems with the second set of custom data
                const updatedHeadphoneItems = response.data.map((item, index) => {
                    return {
                        ...item,
                        id: headphoneIds[index % headphoneIds.length],
                        name: headphoneNames[index % headphoneNames.length],
                        price: headphonePrices[index % headphonePrices.length],
                        image: headphoneImages[index % headphoneImages.length],
                    };
                });

                //FURNITURE-ITEM
                setChairs(response.data.map((chair, index) => ({
                    ...chair,
                    id: chairIds[index % chairIds.length],
                    name: chairNames[index % chairNames.length],
                    price: chairPrices[index % chairPrices.length],
                    image: chairImages[index % chairImages.length]
                })));
                setTables(response.data.map((table, index) => ({
                    ...table,
                    id: tableIds[index % tableIds.length],
                    name: tableNames[index % tableNames.length],
                    price: tablePrices[index % tablePrices.length],
                    image: tableImages[index % tableImages.length]
                })));
                setSofas(response.data.map((sofa, index) => ({
                    ...sofa,
                    id: sofaIds[index % sofaIds.length],
                    name: sofaNames[index % sofaNames.length],
                    price: sofaPrices[index % sofaPrices.length],
                    image: sofaImages[index % sofaImages.length]
                })));

                //FASHIONS-ITEM
                setShirts(response.data.map((shirt, index) => ({
                    ...shirt,
                    id: shirtIds[index % shirtIds.length],
                    name: shirtNames[index % shirtNames.length],
                    price: shirtPrices[index % shirtPrices.length],
                    image: shirtImages[index % shirtImages.length]
                })));
                setJeans(response.data.map((jean, index) => ({
                    ...jean,
                    id: jeanIds[index % jeanIds.length],
                    name: jeanNames[index % jeanNames.length],
                    price: jeanPrices[index % jeanPrices.length],
                    image: jeanImages[index % jeanImages.length]
                })));
                setShoes(response.data.map((shoe, index) => ({
                    ...shoe,
                    id: shoeIds[index % shoeIds.length],
                    name: shoeNames[index % shoeNames.length],
                    price: shoePrices[index % shoePrices.length],
                    image: shoeImages[index % shoeImages.length]
                })));

                //FITNESS-ITEM
                setYogamats(response.data.map((yogamat, index) => ({
                    ...yogamat,
                    id: yogamatIds[index % yogamatIds.length],
                    name: yogamatNames[index % yogamatNames.length],
                    price: yogamatPrices[index % yogamatPrices.length],
                    image: yogamatImages[index % yogamatImages.length]
                })));
                setDumbells(response.data.map((dumbell, index) => ({
                    ...dumbell,
                    id: dumbellIds[index % dumbellIds.length],
                    name: dumbellNames[index % dumbellNames.length],
                    price: dumbellPrices[index % dumbellPrices.length],
                    image:dumbellImages[index %dumbellImages.length]
                })));
                setPunchingbags(response.data.map((punchingbag, index) => ({
                    ...punchingbag,
                    id: punchingbagIds[index % punchingbagIds.length],
                    name: punchingbagNames[index % punchingbagNames.length],
                    price: punchingbagPrices[index % punchingbagPrices.length],
                    image: punchingbagImages[index % punchingbagImages.length]
                })));

                setItems(updatedItems); // Set updated items to state
                setCameraItems(updatedCameraItems); // Set the second set of items
                setHeadphoneItems(updatedHeadphoneItems); // Set the third set of items
            })
            .catch(error => {
                console.log("error is happened", error);
            })
    }, [])


    return (
        <>
            <div className="container-product container-4">
                <div className="product-txt-row"><h2>OUR &nbsp;PRODUCTS</h2></div>
                <div className="row-product ourproducts ">
                    <div className="col-2 col-t-5  col-p-10 col-IL-4 boxes electronic" onClick={handleExploreClick}>
                        <img src="https://img.freepik.com/premium-photo/futuristic-gadgets-showcase-lineup-sleek-modern-technological-devices_977107-681.jpg?w=740" alt="" height="100%" width="100%" />
                        <div className="flex justify-cont elect-txt">
                            <button className="product-button"  >Electronics</button>
                        </div>
                    </div>

                    <div className="col-2 col-t-5  col-p-10 col-IL-4 boxes Furniture" onClick={handleFurnitureClick}>
                        <img src="https://m.media-amazon.com/images/I/91PMLbNLI9L._SL1500_.jpg" alt="" height="100%" width="100%" />
                        <div className="flex justify-cont furniture-txt">
                            <button className="product-button">Furnitures</button>
                        </div>

                    </div>
                    <div className="col-2 col-t-5  col-p-10 col-IL-4 boxes Fashion" onClick={handleFashionsClick}>
                        <img src="https://i.pinimg.com/736x/ea/a6/a9/eaa6a92cfb46a52bdc1cd5978071ff64.jpg" alt="" height="100%" width="100%" />
                        <div className="flex justify-cont fashion-txt">
                            <button className="product-button">Fashions</button>
                        </div>
                    </div>
                    <div className="col-2 col-t-5  col-p-10 col-IL-4 boxes Sports" onClick={handleSportsClick}>
                        <img src="https://i.pinimg.com/736x/4a/6f/fe/4a6ffeaa0e03a12844547b408304e44e.jpg" alt="" height="100%" width="100%" />
                        <div className="flex justify-cont sports-txt">
                            <button className="product-button">Fitness</button>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Ourproducts;