import { useLocation } from "react-router-dom";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../Navbar/Navbar";
import Footer from "../Footer/Footer";
import './Login.css';
import './LoginRes.css';
import axios from "axios";
import Mobilemenu from "../Mobilemenu/Mobilemenu";

const Login = () => {
    const navigate = useNavigate();

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [errors, setErrors] = useState({ email: '', password: '' });
    const [error, setError] = useState('');


    const SignupHandleClick = () => {
        navigate('/signup'); //navigate to the wishlist page
    }

    // Scroll to top when page loads
    useEffect(() => {
        window.scrollTo(0, 0); // Page ko top pe scroll karen
    }, []);

    const validateForm = () => {
        let isValid = true;
        const errors = { email: '', password: '' };

        // Email validation
        if (!email) {
            errors.email = 'Email is required';
            isValid = false;
        } else if (!/\S+@\S+\.\S+/.test(email)) {
            errors.email = 'Enter a valid email';
            isValid = false;
        }

        // Password validation
        if (!password) {
            errors.password = 'Password is required';
            isValid = false;
        } else if (password.length < 6) {
            errors.password = 'Password must be at least 6 characters';
            isValid = false;
        }

        setErrors(errors);
        return isValid;
    };


    const handleSignIn = (e) => {
        e.preventDefault(); // Page reload nahi hoga
    
        if (validateForm()) {
                navigate('/')
                console.log("login successfully")
        } else {
            console.log('Form is invalid');
        }
    };

    

    return (
        <>
            <Navbar />
            <div className="container-login">
                <div id="row-login" className="row-login justify-cont align-cent text-ali">
                    <div className="col-12 col-m-12 col-m-6 col-t-12 col-IL-12 justify-cont align-cent text-ali">
                        <div className="title-text">
                            <h3>LOGIN</h3>
                            <p className="mtfifteen fseighteen">Home / Sign in</p>
                        </div>
                    </div>
                </div>
            </div>

            <div className="container-login">
                <div className="row-login justify-cont align-cent" id="row-login2">
                    <div className="col-5 col-p-12 col-m-12 col-t-12 col-k-12 login-box flex">
                        <div className="email">
                            Email * <br />
                            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)}  />
                            {errors.email && <p className="error">{errors.email}</p>}  {/* Error message */}
                        </div>

                        <div className="password">
                            Password * <br />
                            <input type="password" value={password}  onChange={(e) => setPassword(e.target.value)}  />
                            {errors.password && <p className="error">{errors.password}</p>}  {/* Error message */}
                        </div>

                        <button className="signin-btn" onClick={handleSignIn}>SIGNIN</button>
                        {error && <p className="error">{error}</p>}  {/* Display error message */}
                        
                        <div className="flex space-bet act-pss-btn">
                            <button className="widthhalf-percent create-acc-btn" onClick={SignupHandleClick} >CREATE ACCOUNT</button>
                            <button className="widthhalf-percent forgot-pass-btn">FORGOT PASSWORD?</button>
                        </div>
                    </div>
                </div>
            </div>
            <Footer />
            <Mobilemenu />
        </>
    )
}

export default Login;