import React from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import './Footer.css';
import './FooterRes.css';

const Footer = () => {
    const navigate = useNavigate();
    const handleWishlistClick=()=>{
        navigate('/wishlist'); //navigate to the wishlist page
    }
    const LoginHandleClick=()=>{
        navigate('/login'); //navigate to the wishlist page
    }
    const handleCartClick=()=>{
        navigate('/cart')
    }
    const handleAboutClick=()=>{
        navigate('/about')
    }
    return (
        <div className="container-footer">
            <div className="row-footer">
                <div className="col-3 col-m-6 col-p-12 col-t-6  footer-col">
                    <p>ABOUT US</p>
                    <div className="about-txt">
                        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit.  reiciendis minima blanditiis quae quibusdam expedita facilis id deleniti enim? </p>
                    </div>
                </div>
                <div className="col-3 col-m-6 col-p-12 col-t-6  footer-col">
                    <ul>INFORMATION
                        <li onClick={handleAboutClick}>About Us</li>
                        <li>Manufactures</li>
                        <li>Tracking Order</li>
                        <li>Privacy & Policy</li>
                        <li>Terms & Conditions</li>
                    </ul>
                </div>
                <div className="col-3 col-m-6 col-p-12 col-t-6  footer-col">
                    <ul>MY ACCOUNT
                        <li onClick={LoginHandleClick}>Login</li>
                        <li onClick={handleCartClick}>My Cart</li>
                        <li onClick={handleWishlistClick} className="My-cart">Wishlist</li>
                        <li>My Account</li>
                    </ul>
                </div>
                <div className="col-3 col-m-6 col-p-12 col-t-6  footer-col">
                    <p>NEWSLETTER</p>
                    <input type="text" placeholder="Enter-E-Mail Address" className="footer-input" /> <br />
                    <button className="footer-btn">Subscribe</button>
                </div>
            </div>
            <div className="row-footer2">
                <p>2024, MyShop, Made with React by <strong>PRIYAKANT TYAGI</strong></p>
            </div>
        </div>
    )
}

export default Footer;