import { useLocation } from "react-router-dom";
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../Navbar/Navbar";
import Footer from "../Footer/Footer";
import Mobilemenu from "../Mobilemenu/Mobilemenu";
import './About.css';
import './AboutRes.css';

const About = () => {
    const navigate = useNavigate();
    const LoginHandleClick = () => {
        navigate('/login'); //navigate to the wishlist page
    }

    // Scroll to top when page loads
    useEffect(() => {
        window.scrollTo(0, 0); // Page ko top pe scroll karen
    }, []);

    return (
        <>
            <Navbar />
            <div className="container-about">
                <div id="row-about" className="row-about justify-cont align-cent text-ali">
                    <div className="col-12 col-m-12 col-m-6 col-t-12 col-IL-12 justify-cont align-cent text-ali">
                        <div className="title-text">
                            <h3>ABOUT</h3>
                            <p className="mtfifteen fseighteen">Home / About Us</p>
                        </div>
                    </div>
                </div>
            </div>

            <div className="container-about">
                <div className="row-about justify-cont align-cent" id="row-about2">
                    <div className="about-boxx">
                        <h2 className="about-box-txt">
                            "Our e-commerce website offers a seamless shopping experience with a variety of categories like Electronics, Furniture, and Fashion, designed to meet all your needs."
                        </h2>
                    </div>
                    <div className="col-6 col-p-12 col-k-12 col-m-12 col-t-12 col-IL-12 img-box">
                        <img src="https://furns-react.netlify.app/_ipx/w_1080,q_75/%2Fimages%2Fabout%2F02.jpg?url=%2Fimages%2Fabout%2F02.jpg&w=1080&q=75" alt="Furniture's-walpaper" width="100%" />
                        <h3 className="h3-heading">OUR STORIES</h3>
                        <div className="img-box-p">
                            <p>At Our Website, we’re passionate about bringing you the best in quality, style, and innovation. From carefully curated collections to exceptional customer experiences, every product tells a story of craftsmanship and care. </p>
                        </div>
                    </div>
                    <div className="col-6 col-p-12 col-k-12 col-m-12 col-t-12 col-IL-12 img-box">
                        <img src="https://images.pexels.com/photos/356056/pexels-photo-356056.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" alt="Electronic's Walpaper" width="100%" />
                        <h3 className="h3-heading">OUR MISSION</h3>
                        <div className="img-box-p">
                            <p>Our mission is to deliver exceptional products that blend quality, affordability, and style. We aim to create a seamless shopping experience, empowering you to find exactly what you need to enhance your lifestyle.</p>
                        </div>
                    </div>
                </div>
            </div>
            <Footer />
            <Mobilemenu />
        </>
    )
}

export default About;