import { useLocation } from "react-router-dom";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../Navbar/Navbar";
import Footer from "../Footer/Footer";
import './Contact.css';
import './ContactRes.css';
import Mobilemenu from "../Mobilemenu/Mobilemenu";

const Contact = () => {
    const navigate = useNavigate();

    // Scroll to top when page loads
    useEffect(() => {
        window.scrollTo(0, 0); // Page ko top pe scroll karen
    }, []);

    // State for form inputs and error messages
    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        subject: '',
        message: '',
    });
    const [errors, setErrors] = useState({});

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value
        });
    };

    // Form Validation function
    const validateForm = () => {
        const newErrors = {};

        // Check if fields are empty
        if (!formData.firstName) newErrors.firstName = "First name is required!";
        if (!formData.lastName) newErrors.lastName = "Last name is required!";
        if (!formData.subject) newErrors.subject = "Subject is required!";
        if (!formData.message) newErrors.message = "Message is required!";

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0; // If no errors, return true
    };

    // Handle signup button click
    const handleSubmit = (e) => {
        e.preventDefault();
        if (validateForm()) {
            // Form is valid, proceed with signup (e.g., send data to API)
            console.log("Form Submitted", formData);
            navigate('/');
        }
    };


    return (
        <>
            <Navbar />
            <div className="container-contact">
                <div id="row-contact" className="row-contact justify-cont align-cent text-ali">
                    <div className="col-12 col-m-12 col-m-6 col-t-12 col-IL-12 justify-cont align-cent text-ali">
                        <div className="title-text">
                            <h3>CONTACT</h3>
                            <p className="mtfifteen fseighteen">Home / Contact</p>
                        </div>
                    </div>
                </div>
            </div>

            <div className="container-contact">
                <div className="row-contact justify-cont align-cent" id="row-contact2">
                    <div className="col-5 col-p-12 col-m-12 col-t-12 col-k-12 login-box flex">
                        <div className="flex space-bet name-input">
                            <div className="widthhalf">First Name * <input type="text" value={formData.firstName} name="firstName" onChange={handleInputChange} /></div>


                            <div className="widthhalf">Last Name * <input type="text" value={formData.lastName} name="lastName" onChange={handleInputChange} /></div>

                        </div>
                        <div className="flex space-evenly">
                            {errors.firstName && <span className="error">{errors.firstName}</span>}
                            {errors.lastName && <span className="error">{errors.lastName}</span>}
                        </div>

                        <div className="subject">
                            Subject * <br />
                            <input type="text" name="subject" value={formData.subject} onChange={handleInputChange} />
                        </div>
                        {errors.subject && <span className="error">{errors.subject}</span>}
                        <div className="message">
                            Message * <br />
                            <textarea value={formData.message} name="message" onChange={handleInputChange}></textarea>
                        </div>
                        {errors.message && <span className="error">{errors.message}</span>}
                        <button className="send-btn" onClick={handleSubmit}>SEND MESSAGE</button>
                    </div>
                </div>
            </div>
            <Footer />
            <Mobilemenu />
        </>
    )
}

export default Contact;