import React from "react";
import './Moblemenu.css';
import './MobilemenuRes.css';
import { FaHome } from 'react-icons/fa'; 
import { FaRegHeart } from 'react-icons/fa';
import { FaCartPlus } from 'react-icons/fa';
import { FaSignInAlt } from 'react-icons/fa';
import { Navigate, useNavigate } from "react-router-dom";


const Mobilemenu = () => {
    const navigate = useNavigate();
    const handleHomeClick=()=>{
        navigate('/')
    }
    const handleWishlistClick=()=>{
        navigate('/wishlist')
    }
    const handleCartClick=()=>{
        navigate('/cart')
    }
    const handleLoginClick=()=>{
        navigate('/login')
    }
    return (
        <>
            <div className="container-mob-menu">
                <div className="row-mob-menu justify-cont align-cent">
                    <ul className="flex mob-menu-ul space-bet">
                        <li className="text-ali mob-menu-li" onClick={handleHomeClick}>
                            <FaHome className="mob-menu-icon"/> <br />
                            <span>Home</span>
                        </li>
                        <li className="text-ali mob-menu-li" onClick={handleWishlistClick}>
                            <FaRegHeart className="mob-menu-icon"/> <br />
                            <span>Wishlist</span>
                        </li>
                        <li className="text-ali mob-menu-li" onClick={handleCartClick}>
                            <FaCartPlus className="mob-menu-icon"/>
                            <br />
                            <span>Cart</span>
                        </li>
                        <li className="text-ali mob-menu-li" onClick={handleLoginClick}>
                            <FaSignInAlt className="mob-menu-icon"/>
                            <br />
                            <span>Login</span>
                        </li>
                    </ul>
                </div>
            </div>
        </>
    )
}

export default Mobilemenu;