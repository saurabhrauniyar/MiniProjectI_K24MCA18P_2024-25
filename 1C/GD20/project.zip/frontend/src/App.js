import logo from './logo.svg';
import './App.css';
import {BrowserRouter , Route ,Routes} from 'react-router-dom'
import Home from './Components/Home';

import SignIn from './Components/Auth/SignIn'
import SignUp from './Components/Auth/SignUp'

import HomeNew from './Components/HomeNew';
import About from './Components/About';
import Diet from './Components/Diet';
import Premium from './Premium';
import Feedback from './Components/Feedback';

function App() {
  return (
    <BrowserRouter>
      <div className="App">
        <Routes>
          <Route path='/' element={<HomeNew/>}></Route>
          <Route path='/home' element={<Home/>}></Route>
          <Route path='/signup' element={<SignUp/>}></Route>
          <Route path='/signin' element={<SignIn/>}></Route>
          <Route path='/about' element={<About/>}></Route>
          <Route path='/Diet' element={<Diet/>}></Route>
          <Route path='/premium' element={<Premium/>}></Route>
          <Route path='/feedback' element={<Feedback/>}></Route>
         

        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;
