import React, { useEffect } from 'react'
import {useNavigate} from 'react-router-dom'
import Navbar from './Navbar'

import pic from './Images/front.jpg'



function HomeNew() {

    const navigate = useNavigate()

    useEffect(() => {
        const token = localStorage.getItem("jwt");
        if(!token){
          navigate('/signin')
        }

    }, []);


  return (

    
    
    <div className="min-h-screen bg-gradient-to-b from-yellow-300 to-white p-4">
    {/* Navbar */}
    <div className="bg-white p-4 shadow-md rounded-md w-full">
      <Navbar />
      
    </div>
    

  {/* Content Section */}
  <div className="flex flex-col items-center gap-6 mt-8">
      {/* Animated Button */}
      <button
        className="bg-yellow-500 text-white font-medium px-6 py-2 rounded-md shadow-md 
        hover:bg-yellow-600 transition duration-300 transform hover:scale-110 
        hover:rotate-3 active:scale-100 active:rotate-0 
        focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:ring-opacity-50
        animate-button"
        onClick={() => navigate('/home')}
      >
        Go to Recipes
      </button>

      {/* Animated Image */}
      <img
        src={pic} // Make sure to replace with your image source
        alt="Delicious Recipes"
        className="w-full max-w-md rounded-lg shadow-lg 
        transform transition duration-500 hover:scale-105 hover:rotate-6 
        hover:shadow-xl animate-fade-in"
      />
    </div>
</div>

  )
}

export default HomeNew