import { useState } from "react";
import React from "react";
function Diet(){
    const [selectedDay, setSelectedDay] = useState("Monday");

  const dietData = {
    Monday: {
      breakfast: "Oatmeal with fruits and nuts",
      lunch: "Grilled chicken with quinoa and steamed vegetables",
      dinner: "Salmon with sweet potatoes and green beans",
    },
    Tuesday: {
      breakfast: "Scrambled eggs with avocado toast",
      lunch: "Turkey sandwich on whole grain bread with a side salad",
      dinner: "Beef stir-fry with brown rice",
    },
    Wednesday: {
      breakfast: "Greek yogurt with granola and berries",
      lunch: "Grilled chicken Caesar salad",
      dinner: "Baked cod with roasted vegetables",
    },
    Thursday: {
      breakfast: "Protein shake with a banana",
      lunch: "Grilled shrimp with couscous and asparagus",
      dinner: "Chicken curry with basmati rice",
    },
    Friday: {
      breakfast: "Whole-grain pancakes with maple syrup",
      lunch: "Tuna salad wrap with a side of fruit",
      dinner: "Vegetable pasta with grilled chicken",
    },
    Saturday: {
      breakfast: "Smoothie bowl with chia seeds and fruit",
      lunch: "Beef tacos with guacamole and salsa",
      dinner: "Grilled steak with mashed potatoes and broccoli",
    },
    Sunday: {
      breakfast: "Egg omelet with spinach and mushrooms",
      lunch: "Grilled salmon with a quinoa salad",
      dinner: "Vegetarian chili with cornbread",
    },
  };
    return(
        <div>
           <div className="diet-plan bg-gradient-to-br from-yellow-100 to-white py-12 px-6 min-h-screen">
      <div className="max-w-4xl mx-auto text-center">
        <h1 className="text-3xl font-bold text-yellow-600 mb-8">
          7-Day Gym Diet Plan
        </h1>
        {/* Day Buttons */}
        <div className="flex justify-center gap-4 mb-6 flex-wrap">
          {Object.keys(dietData).map((day) => (
            <button
              key={day}
              onClick={() => setSelectedDay(day)}
              className={`px-4 py-2 rounded-lg font-medium ${
                selectedDay === day
                  ? "bg-yellow-500 text-white"
                  : "bg-white text-gray-700 border border-yellow-500 hover:bg-yellow-100"
              } transition`}
            >
              {day}
            </button>
          ))}
        </div>

        {/* Diet Details */}
        <div className="diet-details bg-white p-6 rounded-lg shadow-lg">
          <h2 className="text-2xl font-semibold text-yellow-600 mb-4">
            {selectedDay}'s Diet Plan
          </h2>
          <div className="text-left text-gray-700">
            <p className="mb-2">
              <span className="font-bold">Breakfast:</span> {dietData[selectedDay].breakfast}
            </p>
            <p className="mb-2">
              <span className="font-bold">Lunch:</span> {dietData[selectedDay].lunch}
            </p>
            <p>
              <span className="font-bold">Dinner:</span> {dietData[selectedDay].dinner}
            </p>
          </div>
        </div>
      </div>
    </div>
  

        </div>
    )
}
export default Diet