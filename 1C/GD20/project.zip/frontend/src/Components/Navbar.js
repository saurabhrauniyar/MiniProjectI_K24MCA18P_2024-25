import React from 'react'
import './CSS/Navbar.css'
import {useNavigate} from 'react-router-dom'
import logorecipe from "./Images/recipelogo.jpeg"

function Navbar() {

    const navigate = useNavigate()

  return (
    <div className="flex justify-between items-center px-4 py-2 bg-gradient-to-r from-yellow-400 to-white shadow-md">
    {/* Logo Section */}
    <div className="logo">
      <div className="logo-container">
        <img
          src={logorecipe}
          className="logo img-fluid"
          alt="Logo"
          width="50"
          height="50"
        />
      </div>
    </div>
  
    {/* Button Section */}
    <div className="btnsss flex gap-4">
      <p
        className="cursor-pointer inline text-sm font-medium text-slate-700 hover:text-slate-600"
        onClick={() => navigate('/about')}
      >
        ABOUT
      </p>
      <p
        className="cursor-pointer inline text-sm font-medium text-slate-700 hover:text-slate-600"
        onClick={() => navigate('/diet')}
      >
        DIET
      </p>
      <p
        className="cursor-pointer inline text-sm font-medium text-slate-700 hover:text-slate-600"
        onClick={() => navigate('/premium')}
      >
       PREMIUM
      </p>
      
      <p
        className="cursor-pointer inline text-sm font-medium text-slate-700 hover:text-slate-600"
        onClick={() => {
          localStorage.clear();
          window.location.reload();
        }}
      >
        LOGOUT
      </p>
    </div>
  </div>
  
  

  )
}

export default Navbar