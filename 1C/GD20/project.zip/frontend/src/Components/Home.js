import React, { useEffect, useState } from "react";
import axios from "axios";

import {useNavigate} from 'react-router-dom'

import Navbar from "./Navbar";


import './CSS/Home.css'

function Home() {

    const navigate = useNavigate();
    
    const [ingredients, setIngredients] = useState("");
    const [recipes, setRecipes] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");


    
    useEffect(() => {
        const token = localStorage.getItem("jwt");
        if(!token){
          navigate('/signin')
        }

    }, []);




    const chk = () => {
        console.log(recipes);
    }
    const chk2 = () => {
        console.log(ingredients);
    }

    const apiKey = "a8e44e1edee94498a36ccb1128961231";

    const fetchRecipes = async () => {
        if (!ingredients.trim()) {
            setError("Please enter some ingredients.");
            return;
        }

        setError("");
        setLoading(true);
        try {
            console.log("Fetching recipes with ingredients:", ingredients); // Debug log
            const response = await axios.get(
                "https://api.spoonacular.com/recipes/findByIngredients", // Corrected URL
                {
                    params: {
                        ingredients: ingredients.split(",").map((item) => item.trim()).join(","),
                        number: 5,
                        apiKey,
                    },
                }
            );
            console.log("API Response:", response.data); // Debug log
            setRecipes(response.data);
        } catch (err) {
            console.error("API Error:", err.response ? err.response.data : err.message);
            setError("Failed to fetch recipes. Please try again.");
        } finally {
            setLoading(false);
        }
    };



    return (
       <div>
        <Navbar/>
        <div className="container mx-auto p-6 bg-gradient-to-b from-yellow-100 to-white min-h-screen">
  <h1 className="title text-3xl font-bold text-yellow-600 mb-6 text-center">
    Recipe Finder
  </h1>

  {/* Input Section */}
  <div className="flex flex-col items-center gap-4 mb-6">
    <input
      type="text"
      placeholder="Enter ingredients (comma-separated)"
      value={ingredients}
      onChange={(e) => setIngredients(e.target.value)}
      className="input w-full max-w-md px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-yellow-500"
    />
    <button
      onClick={fetchRecipes}
      className="button bg-yellow-500 text-white font-medium px-6 py-2 rounded-md shadow-md hover:bg-yellow-600 transition duration-300"
    >
      Search Recipes
    </button>
  </div>

  {/* Loading and Error Messages */}
  {loading && (
    <p className="text-center text-gray-600 font-medium">Loading...</p>
  )}
  {error && <p className="error text-center text-red-500 font-medium">{error}</p>}

  {/* Recipes Section */}
  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
    {recipes.map((recipe) => (
      <div
        key={recipe.id}
        className="p-4 border border-gray-200 rounded-lg shadow-md bg-white"
      >
        <h3 className="text-lg font-semibold text-red-500 mb-2">
          {recipe.title}
        </h3>
        <img
          className="indImage w-full h-40 object-cover rounded-md mb-4"
          src={recipe.image}
          alt={recipe.title}
        />
        <p className="Ingredients text-yellow-600 font-medium mb-2">
          Used Ingredients:
        </p>
        <ul className="list-disc pl-5 mb-4 text-gray-700">
          {recipe.usedIngredients.map((ingredient) => (
            <li key={ingredient.id}>{ingredient.name}</li>
          ))}
        </ul>
        <p className="text-yellow-600 font-medium mb-2">Missed Ingredients:</p>
        <ul className="list-disc pl-5 text-gray-700">
          {recipe.missedIngredients.map((ingredient) => (
            <li key={ingredient.id}>
              {ingredient.name} ({ingredient.amount} {ingredient.unit})
            </li>
          ))}
        </ul>
      </div>
    ))}
  </div>
</div>

       </div>
    )




}




export default Home