import React, { useEffect, useState } from 'react'
// import './SignUp.css'
import { Link, useNavigate } from 'react-router-dom'
import { ToastContainer, toast } from 'react-toastify';
import './SignUp.css'

function SignIn() {

    const navigate = useNavigate()

    
    const [email, setEmail] = useState("");
   
    const [password, setPassword] = useState("");


    const notifyA = (msg) => toast.error(msg);
    const notifyB = (msg) => toast.success(msg);
    const emailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;


    const postData = () => {
        //checking Email
        if (!emailRegex.test(email)) {
            notifyA("Invalid Email");
            return;
        }

        //sending data to server
        fetch("http://localhost:5000/signin", {
            method: "post",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                email: email,
                password: password,
            }),
        })
            .then((res) => res.json())
            .then((data) => {
                if (data.error) {
                    notifyA(data.error);
                } else {
                    notifyB("Signed In successfullly");
                    console.log(data);
                    localStorage.setItem("jwt", data.token);
                    localStorage.setItem("user", JSON.stringify(data.user));
                    // setUserLogin(true);
                    navigate("/");
                }

                console.log(data);
            });
    };

  return (
    <div className="signUp bg-gradient-to-br from-yellow-300 to-white min-h-screen flex items-center justify-center">
    <div className="form-container bg-white p-8 rounded-lg shadow-lg w-96 transform transition duration-500 hover:scale-105 hover:shadow-2xl">
      <h1 className="text-2xl font-bold text-yellow-500 mb-6 text-center animate__animated animate__fadeIn animate__delay-1s">
        Login Page
      </h1>
      <div>
        {/* Email Input */}
        <div className="input-group mb-4 animate__animated animate__fadeIn animate__delay-2s">
          <input
            type="email"
            name="email"
            id="email"
            placeholder="Email"
            value={email}
            onChange={(e) => {
              setEmail(e.target.value);
            }}
            className="w-full p-3 border border-yellow-400 rounded-md focus:outline-none focus:ring-2 focus:ring-yellow-500 transform transition duration-300 hover:border-yellow-500"
          />
        </div>

        {/* Password Input */}
        <div className="input-group mb-6 animate__animated animate__fadeIn animate__delay-3s">
          <input
            type="password"
            name="pass"
            id="pass"
            placeholder="Password"
            value={password}
            onChange={(e) => {
              setPassword(e.target.value);
            }}
            className="w-full p-3 border border-yellow-400 rounded-md focus:outline-none focus:ring-2 focus:ring-yellow-500 transform transition duration-300 hover:border-yellow-500"
          />
        </div>

        {/* Submit Button */}
        <input
          type="submit"
          id="submit-btn"
          value="SignIn"
          onClick={() => {
            postData();
          }}
          className="w-full bg-yellow-500 text-white py-3 rounded-md hover:bg-yellow-600 transition transform hover:scale-105 hover:shadow-xl"
        />
      </div>

      {/* Sign Up Link */}
      <Link
        style={{ textDecoration: "none" }}
        className="signin-link block mt-4 text-center text-yellow-500 hover:underline transform transition duration-300 hover:scale-105"
        to={"/signup"}
      >
        <span>Signup</span>
      </Link>
    </div>
  </div>

  )
}

export default SignIn