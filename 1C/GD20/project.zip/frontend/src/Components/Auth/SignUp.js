import React, { useEffect, useState } from 'react'
// import './SignUp.css'
import { Link, useNavigate } from 'react-router-dom'
import { ToastContainer, toast } from 'react-toastify';
import './SignUp.css'

function SignUp() {

    const navigate = useNavigate()

    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [userName, setuserName] = useState("");
    const [password, setPassword] = useState("");
   
    const [ip, setIp] = useState("");


    const notifyA = (msg) => toast.error(msg)
    const notifyB = (msg) => toast.success(msg)
    const emailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/




    useEffect(() => {

    }, []);
  
  
  
    const postData = () => {
  
      //checking Email
      if(!emailRegex.test(email)){
          notifyA("Invalid Email")
          return
      }
  
    //   fetch("https://api.ipify.org").
    //   then((res) => res.text())
    //   .then(ip => setIp(ip))
    //   .catch(err => console.log(err))
  
      //sending data to server 
      fetch("http://localhost:5000/signup" , {
          method:"post",
          headers: {
              "Content-Type" : "application/json"
          },
          body:JSON.stringify({
              name:name,
              email:email.toLowerCase(),
              userName:userName,
              password:password,
              ip:ip
  
          })
  
          
      }).then(res => res.json())
      .then(data => {
          if(data.error){
              notifyA(data.error)
          }else{
              notifyB(data.message)
              navigate('/signin')
          }
          
          console.log(data)})
  }



  const gotootheruser = () => {
    navigate('/userview')
  }



  return (
    <div className="signUp bg-gradient-to-br from-yellow-300 to-white min-h-screen flex items-center justify-center">
    <div className="form-container bg-white p-8 rounded-lg shadow-lg w-96">
      <h1 className="text-2xl font-bold text-yellow-500 mb-6 text-center">SignUp Page</h1>
      <div>
        <div className="input-group mb-4">
          <input
            type="email"
            name="email"
            id="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full p-3 border border-yellow-400 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500"
          />
        </div>
        <div className="input-group mb-4">
          <input
            type="text"
            name="name"
            id="name"
            placeholder="Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full p-3 border border-yellow-400 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500"
          />
        </div>
        <div className="input-group mb-4">
          <input
            type="text"
            name="userName"
            id="userName"
            placeholder="Username"
            value={userName}
            onChange={(e) => setuserName(e.target.value)}
            className="w-full p-3 border border-yellow-400 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500"
          />
        </div>
        <div className="input-group mb-6">
          <input
            type="password"
            name="pass"
            id="pass"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full p-3 border border-yellow-400 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500"
          />
        </div>
        <input
          type="submit"
          id="submit-btn"
          value="SignUp"
          onClick={postData}
          className="w-full bg-yellow-500 text-white py-3 rounded-lg hover:bg-yellow-600 transition duration-300"
        />
      </div>
      <Link
        style={{ textDecoration: "none" }}
        className="signin-link block mt-4 text-center text-yellow-500 hover:underline"
        to="/signin"
      >
        <span>Signin</span>
      </Link>
    </div>
  </div>
  
  )
}

export default SignUp