import React from "react";
export default function Feedback(){
    return(
        <div>
            guguuugu
        </div>
    )
}