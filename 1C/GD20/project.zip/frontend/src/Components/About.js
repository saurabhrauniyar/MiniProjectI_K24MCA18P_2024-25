import React from "react";

function About(){
    return(
      <div className="about-section bg-gradient-to-br from-yellow-100 to-white py-12 px-6">
      <div className="max-w-4xl mx-auto text-center">
        <h1 className="text-3xl font-bold text-yellow-600 mb-6 animate-fadeInUp">
          About Us
        </h1>
        <p className="text-lg text-gray-700 leading-relaxed animate-fadeInUp mt-4 delay-200">
          Welcome to our Recipe Finder app – your ultimate kitchen companion! 
          Our app is designed to make cooking fun, easy, and exciting. Whether you're a seasoned chef or a novice in the kitchen, 
          you'll find recipes tailored to your tastes, preferences, and available ingredients.
        </p>
        <p className="text-lg text-gray-700 leading-relaxed animate-fadeInUp mt-4 delay-400">
          With an extensive collection of recipes from around the world, 
          we aim to inspire your culinary journey. Use our powerful search tool to discover dishes that suit your mood, 
          dietary preferences, or simply what you have in your pantry. 
        </p>
        <p className="text-lg text-gray-700 leading-relaxed animate-fadeInUp mt-4 delay-600">
          Cooking is more than just a necessity – it's an art. 
          Let us help you explore new flavors, create memorable meals, and bring joy to your table. 
          Start your journey today and make every meal an adventure!
        </p>
        <p className="text-lg text-gray-700 leading-relaxed animate-fadeInUp mt-4 delay-800">
          Happy Cooking! 🍳
        </p>
      </div>
    </div>
    
    
    )
}

export default About;