
import React from "react";
export default function Premium(){

    return (
        <div className="premium-page bg-gradient-to-br from-yellow-100 to-white min-h-screen flex items-center justify-center">
          <div className="text-center p-6 rounded-lg shadow-xl bg-white w-full max-w-md">
            {/* Animated Icon */}
            <div className="flex justify-center mb-6">
              <div className="w-16 h-16 bg-yellow-400 rounded-full flex items-center justify-center animate-bounce">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-8 w-8 text-white"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M5 13l4 4L19 7"
                  />
                </svg>
              </div>
            </div>
            {/* Heading */}
            <h1 className="text-3xl font-bold text-yellow-600 mb-4">
              Go Premium 🌟
            </h1>
            <p className="text-gray-700 text-lg mb-6">
              Unlock exclusive recipes, personalized meal plans, and more! 
              Take your cooking journey to the next level.
            </p>
            {/* Pricing Plan */}
            <div className="mb-6">
              <p className="text-2xl font-bold text-gray-800">$9.99/month</p>
              <p className="text-sm text-gray-500">Cancel anytime</p>
            </div>
            {/* Call-to-Action Button */}
            <button
              className="w-full bg-yellow-500 text-white py-2 px-4 rounded-lg shadow-lg text-lg font-semibold hover:bg-yellow-600 transition-transform transform hover:scale-105"
              onClick={() => alert("Redirecting to payment...")}
            >
              Buy Premium
            </button>
            {/* Already Subscribed */}
            <p className="mt-4 text-sm text-gray-500">
              Already subscribed?{" "}
              <span
                className="text-yellow-600 font-semibold cursor-pointer hover:underline"
                onClick={() => alert("Redirecting to Premium Content...")}
              >
                Access here
              </span>
            </p>
          </div>
        </div>
      );
    };
    